var jose = require('node-jose');

var fs = require('fs');
var input = fs.readFileSync("/home/ravikumar/Documents/CITI/bot-services/citi-crs-pilot/l.pem");
//RSA keypair
var result = {
    "kty": "RSA",
    "kid": "37c215bf-65c7-4073-ad38-2126940f6f65",
    "n": "7-XOGsqh5Se4UzlP5XypDNzjo3giudWPMz0nxcub9vP9WOdovwv5ORRB0WAQvP_jNNp5dbeeV_rbrCNZE-AyzrqLQQvl7uc23n3BtZEBYKdPK2tQpa-o7juRzjcuaPJHuHfhQJokdrQv-RcFDBEdjppJSVaofnX8daSpoXRm8tZJALxcIG8407fSw1D0La74nHlDkZwINzVYHslGu0jr-MPDDy6pxaTmzZl96oAXoQOHHPlAzZfm0Gd5_s0pOQOpjQzCvqP5JSVP4uKXAvCxQ6GP55mH_gaJq4JN47dv0m5sZielSo_KzS2ULAw2NCwvgDYDW0oReG08wMx9PhZU3w",
    "e": "AQAB"
}

keystore = jose.JWK.createKeyStore()

//For testing purpose, below Kore API can be used to generate the above key holder.
//https://bots.kore.ai/api/1.1/users/u-c7150b6b-b170-510f-bdd5-fc3e4de5bf5b/builder/jwks
// Now pass JWE token to 'update' function below.
jose.JWE.createEncrypt({
    format: "compact",
    "fields": {
        "cty": "jwt"
    }
}, result).
update("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE1NjMyMTMyNTE5MDIsImV4cCI6MTU2MzI5OTY1MTkwMiwiYXVkIjoiaHR0cHM6Ly9pZHByb3h5LmtvcmUuYWkvYXV0aG9yaXplIiwiaXNzIjoiY3MtN2NkMGU5YWYtMGIzNC01NWI5LWI3ZDItZGQ2OTZlZjg3ZThhIiwic3ViIjoiMjBlZDQxNjQtY2RkNi00MWQyLWJhNTItMmJhNzY2YzFmZDEiLCJpc0Fub255bW91cyI6ImZhbHNlIiwic2VjdXJlQ3VzdG9tRGF0YSI6eyJhY2NvdW50SWQiOiIxMjM0MTI1MTI1MTI1NTYiLCJmdXNpb25TaWQiOiIxMjEyNTEyNTEyNSIsInNpdGVJZCI6IjEyNDEyNTEyNTEyNSJ9fQ.6E3dbZJVdPgW0_PLBO2uNUkSKx16jNbePuSVwK2Ehts").
final().
then(function (res22) {
    console.log("----------->", res22);

    keystore.add(input, "pem", {
        "kid": "37c215bf-65c7-4073-ad38-2126940f6f65"
    }).then(function (res) {
        jose.JWE.createDecrypt(keystore).
        decrypt(res22).
        then(function (result) {
            console.log("decrypted text", result);
            console.log("plain text---->", result.plaintext.toString('utf-8'));
        });
    
    });
    // jose.JWE.createDecrypt(keystore, opts).
    //     decrypt(res).
    //     then(function(result) {
    //       // ...
    //     });
    // return res;
});


