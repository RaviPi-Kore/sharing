var sdk = require("./lib/sdk");
var config = require("./config");
var sub = require("./lib/RedisClient.js").createClient(config.redis);
var pub = require("./lib/RedisClient.js").createClient(config.redis);
pub.config("SET", "notify-keyspace-events", "KExA");

function updateRedisWithData(uuid, data) {
    console.log("updating the redis");
try{
 pub.set(uuid, JSON.stringify(data));
 //   pub.set(uuid +":data", JSON.stringify(data));
    pub.expire(uuid, 90);
    sub.subscribe("__keyspace@0__:" + uuid);
}catch(Err){
console.log("Erro while updateing the redis", Err);
}
}

sub.on('message', function (channel, msg) {
    console.log("sub");
    try {
        if (msg == "expired") {
            console.log("Triggered Feedback Message to User on " + channel + " message : " + msg);
            var id = channel.split(":")[1];
console.log("id:"+id);
            pub.get(id + ":data", function (err, reply) {
                var data = JSON.parse(reply);
//console.log(JSON.stringify(data));
                if (data.context && data.context.session && data.context.session.BotUserSession && data.context.session.BotUserSession.isFeedbackTriggered && data.context.session.UserContext.secureCustomData && data.context.session.BotUserSession.isFeedbackTriggered === data.context.session.BotUserSession.fusionSid) {
                    console.log("already triggered the feedback");
                } else {
                   // data.context.session.BotUserSession.isFeebackTriggered = data.context.session.UserContext.secureCustomData.fusionSid;
                    data.toJSON = function () {
                        return {
                            __payloadClass: 'OnMessagePayload',
                            requestId: data.requestId,
                            botId: data.botId,
                            componentId: data.componentId,
                            sendUserMessageUrl: data.sendUserMessageUrl,
                            sendBotMessageUrl: data.sendBotMessageUrl,
                            context: data.context,
                            channel: data.channel,
                            metaInfo: {
                                isTemplate: false,
                                'nlMeta': {
                                    'noPause': true,
                                }
                            },
                            message: "Feedback",
                        }
                    }
                    //pub.set(id + ":data", JSON.stringify(data));
                    data.context.session.BotUserSession.isFeedbackTriggered = data.context.session.BotUserSession.fusionSid;
                    pub.set(id + ":data", JSON.stringify(data));
                    console.log("Sending discard all to nl internally and trigger feedback.");
                    return sdk.sendBotMessage(data);
                }
            });
        }
    } catch (err) {
        console.log("error in feedback", err);
    }
});

module.exports = updateRedisWithData;