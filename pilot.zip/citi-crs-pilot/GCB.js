var sdk = require("./lib/sdk");
var request = require("request");
var _ = require('lodash');
var request = require('request-promise');

var config = require('./config');
var schedular = require('node-schedule');
const NodeCache = require("node-cache");
const cache = new NodeCache();

var TimedQueue = require('./simple-timed-queue.js');
var queues = {};
var consoleFormatterUtil = require('./botFormatterUtil');
var botId = config.credentials.botId;
var botName = config.credentials.botName;

var path = require("path");

var log4js = require('log4js');
var logLevel = config.logLevel;
var logSize = config.logSizeInBytes;
var logfileName = config.logFileName;
var logBackUps = config.logBackUps;

log4js.configure({
    appenders: {
        //botLog: { type: 'file',filename: path.join(__dirname, 'log/botLog.log'), maxLogSize: 209715200 }, // rotation size = 200mb
        CHATBOT: {
            type: 'file',
            filename: logfileName,
            maxLogSize: logSize,
            backups: logBackUps
        }
    },
    categories: {
        //botLog: { appenders: [ 'botLog' ], level: logLevel },
        default: {
            appenders: ['CHATBOT'],
            level: logLevel
        }
    }
});

const logger = log4js.getLogger();
//console.log = (msg) => logger.debug(msg);
console.error = (msg) => logger.error(msg);
console.warn = (msg) => logger.warn(msg);


/*
 * This is the most basic example of BotKit.
 *
 * It showcases how the BotKit can intercept the message being sent to the bot or the user.
 *
 * We can either update the message, or chose to call one of 'sendBotMessage' or 'sendUserMessage'
 */


function init() {
    callOAuthApi();
}

schedular.scheduleJob('*/45 * * * *', function () {
    callOAuthApi();
});

function callOAuthApi() {
    console.log(consoleFormatterUtil.dateTimeStamp() + ' : CallIng the OAuthToken');
    logger.info('CallIng the OAuthToken');
    var data = {
        "grant_type": config.Oauth.grantType,
        "client_id": config.Oauth.clientId,
        "client_secret": config.Oauth.clientSecret,
        "scope": config.Oauth.scope
    }
    var options = {
        method: 'POST',
        form: data,
        uri: config.Oauth.accessTokenUri,
        headers: {
            'content-type': 'application/x-www-form-urlencoded'
        }
    };
    console.log(consoleFormatterUtil.dateTimeStamp() + " " + JSON.stringify(options));
    logger.info(JSON.stringify(options));
    return request(options).then(function (res) {
        //console.log(res);
        cache.set("accessToken", res);
        //console.log("Access Token from cache xxxxxxxxxx  "+cache.get("accessToken"));
        return res; // you can read response here
    }).catch(function (err) {
        return Promise.reject(err);
    });
}

function sendBotMessage(data) {
    return new Promise(function (resolve, reject) {
        if (data) {
            console.log("Sending discard");
            sdk.sendBotMessage(data);
            data.message = "Let me get and agent for you.";
            sdk.sendUserMessage(data);
            resolve("Bot message sent");
        } else {
            reject("UUID not generated");
        }
    })
}

//var agentTransferText = ["Sorry I couldnâ€™t help. Iâ€™ll connect you to a representative.", "I didnâ€™t mean to upset you. A representative is on the way to help. ", "Sorry, Iâ€™m still pretty new to this. Iâ€™ll get a representative for you.", "I apologize if I made you upset. Iâ€™m connecting you to someone now."]

var agentTransferText = ["Sorry I couldnâ€™t help. Iâ€™ll connect you to a representative. Just FYI, it may take a few minutes if they're super busy.", "I didnâ€™t mean to upset you. A representative is on the way to help. Sometimes there's a wait, hopefully not too long.", "Sorry, Iâ€™m still pretty new to this. Iâ€™ll get a representative for you. Sometimes there's a wait, hopefully not too long.", "I apologize if I made you upset. Iâ€™m connecting you to someone now. Just so you know, it may take time if they're all busy."]

function changeText(data, channel) {
    var overrideMessagePayload = {}
    if (channel == "liveperson") {
        //if(false){
        overrideMessagePayload = {
            /*body: JSON.stringify({
                "type": "RichContentEvent",
                "content": {
                    "type": "text",
                    "text": agentTransferText[Math.floor(Math.random() * agentTransferText.length)]
                }
            }),*/
            body: JSON.stringify(agentTransferText[Math.floor(Math.random() * agentTransferText.length)]),
            isTemplate: true
        };
    } else {
        overrideMessagePayload = {
            body: JSON.stringify({
                "text": agentTransferText[Math.floor(Math.random() * agentTransferText.length)]
            }),
            isTemplate: true
        };
    }
    return overrideMessagePayload;
}

//This is used only for bot builder purpose
function getBotProfileDetails() {
    var options = {
        method: 'GET', // Request type
        uri: config.accounts.uri, // get Accounts  Endpoint  
        headers: {
            'content-type': 'application/json'
        }
    };
    return new Promise(function (resolve, reject) {
        //Do async job
        request.get(options, function (err, resp, body) {
            console.log(consoleFormatterUtil.dateTimeStamp() + " " + body);
            logger.info(body);
            if (err) {
                reject(err);
            } else {
                resolve(body);
            }
        })
    })
}

function getBizTokenDetails(data) {
    var options = {
        method: 'GET', // Request type
        uri: config.bizToken.host + '/botkit/citibotservice/getbiztoken/' + data.context.session.BotUserSession.customerId, // get Accounts  Endpoint
        headers: {
            'content-type': 'application/json'
        }
    };
    consoleFormatterUtil.printLog("info", data, JSON.stringify(options));
    logger.info(data.context.session.BotUserSession.customerId + " - " + JSON.stringify(options));
    return new Promise(function (resolve, reject) {
        //Do async job
        request.get(options, function (err, resp, body) {
            consoleFormatterUtil.printLog("info", data, JSON.stringify(body));
            logger.info(data.context.session.BotUserSession.customerId + " - " + JSON.stringify(options));
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(body));
            }
        })
    })
}


function getAPIProfileDetails(bizToken, apiType, DCLocation, data) {
    consoleFormatterUtil.printBizTokenLog("debug", data, bizToken, "Biz token sent to " + apiType + " :" + bizToken);
    logger.debug(bizToken + " - " + data.context.session.BotUserSession.customerId + " - " + "Biz token sent to " + apiType + " :" + bizToken);
    var uuid = consoleFormatterUtil.generateUUID();
    var newResult = JSON.parse(cache.get("accessToken"));
    var apiURL = "";
    if (apiType === "CPS") {
        apiURL = config.profile.chatbotprofileUri;
    } else if (apiType === "APS") {
        apiURL = config.profile.accountsUri;
    } else if (apiType === "REWARDS") {
        apiURL = config.profile.rewardsUri;
    }
    var options = {
        method: 'GET',
        url: apiURL,
        headers: {
            'Cache-Control': 'no-cache',
            Authorization: 'Bearer ' + newResult.access_token,
            bizToken: bizToken,
            DCLocation: DCLocation,
            uuid: uuid,
            Accept: 'application/json',
            businessCode: 'GCB',
            countryCode: 'US',
            'Content-Type': 'application/json',
            client_id: config.profile.clientId,
            channelId: config.profile.channelId
        }
    };
    consoleFormatterUtil.printBizTokenLog("info", data, bizToken, JSON.stringify(options));
    logger.info(data.context.session.BotUserSession.customerId + " - " + JSON.stringify(options));
    return new Promise(function (resolve, reject) {
        //Do async job
        request.get(options, function (err, resp, body) {
            consoleFormatterUtil.printBizTokenLog("info", data, bizToken, apiType + "Response\n" + JSON.stringify(body));
            logger.info(data.context.session.BotUserSession.customerId + " - " + apiType + "Response\n" + JSON.stringify(body));
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(body));
            }
        })
    })

}

function getABARoutingDetails(bizToken, acctNumbers, DCLocation, data) {
    consoleFormatterUtil.printBizTokenLog("debug", data, bizToken, "acctNumbers is ", acctNumbers);
    logger.debug(data.context.session.BotUserSession.customerId + " - " + "acctNumbers is " + acctNumbers);
    var uuid = consoleFormatterUtil.generateUUID();
    var newResult = JSON.parse(cache.get("accessToken"));
    var apiURL = config.profile.routingUri;
    var options = {
        method: 'POST',
        url: apiURL,
        body: {
            'acctNumbers': acctNumbers
        },
        json: true,
        headers: {
            'Cache-Control': 'no-cache',
            Authorization: 'Bearer ' + newResult.access_token,
            bizToken: bizToken,
            DCLocation: DCLocation,
            uuid: uuid,
            Accept: 'application/json',
            businessCode: 'GCB',
            countryCode: 'US',
            'Content-Type': 'application/json',
            client_id: config.profile.clientId,
            channelId: config.profile.channelId
        }
    };
    consoleFormatterUtil.printBizTokenLog("info", data, bizToken, JSON.stringify(options));
    logger.info(data.context.session.BotUserSession.customerId + " - " + JSON.stringify(options));
    return new Promise(function (resolve, reject) {
        request(options, function (err, resp, body) {
            consoleFormatterUtil.printBizTokenLog("info", data, bizToken, "Routing Response\n" + JSON.stringify(body));
            logger.info(data.context.session.BotUserSession.customerId + " - " + "Routing Response\n" + JSON.stringify(body));
            if (err) {
                reject(err);
            } else {
                resolve(body);
            }

        })
    })


    /*return request(options).then(function (res) {
        console.log("Routing Details\n" + JSON.stringify(res));
        return res;
    }).catch(function (err) {
        return Promise.reject(err);
    });*/



}

function userMessage(data, callback) {
    if (data.message == "You are now connected to Chat Bot.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        //data.message = "You are now connected to Chat Bot";
        //Sends back 'Hello' to user.
        return callback;
    } else if (data.message == "You are now connected to Citi Bot.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        //data.message = "You are now connected to Citi Bot";
        //Sends back 'Hello' to user.
        return callback;
    } else if (data.message == "You are now connected to DitBot.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        //data.message = "You are now connected to Citi Bot";
        //Sends back 'Hello' to user.
        return callback;
    } else if (data.message == "You are now connected to CITIBOT.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (data.message == "You are now connected to CitiBot.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (data.message == "You are now connected to Citi® Bot.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (data.message == "Please do not share sensitive account information, such as your security word or expiration date. This session may be recorded or monitored. Hours of Operation are 9AM t        o 10PM.") {
        consoleFormatterUtil.printLog("debug", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (data.message == "Please do not share sensitive account information, such as your security word or expiration date. This session may be recorded or monitored. Hours of Operation are 7AM to 12AM ET.") {
        consoleFormatterUtil.printLog("info", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (data.message == "Please do not share sensitive account information here, such as your security word or expiration date. This session may be recorded or monitored.") {
        consoleFormatterUtil.printLog("info", data, "Ignoring the message " + data.message);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + "Ignoring the message " + data.message);
        return callback;
    } else if (!data.agent_transfer) {
        return sdk.sendBotMessage(data, callback);
    } else {
        data.message = "Agent Message";
        return sdk.sendUserMessage(data, callback);
    }

}

module.exports = {
    botId: botId,
    botName: botName,

    on_user_message: function (requestId, data, callback) {
        console.log("on user Message");
        logger.info("on user Message");
        consoleFormatterUtil.printLog("info", data, "on user message " + JSON.stringify(data.message));
        logger.info(data.context.session.BotUserSession.customerId + " - " + "on user message " + JSON.stringify(data.message));
        var livePersonMsg1 = "Please do not share sensitive account information, such as your security word or expiration date. This session may be recorded or monitored. Hours of Operation are 9AM to 10PM.";
        var livePersonMsg2 = "You are now connected to DitBot.";
        var livePersonMsg3 = "You are now connected to CitiBot.";
        var livePersonMsg4 = "You are now connected to Citi® Bot.";
        var livePersonMsg5 = "Please do not share sensitive account information, such as your security word or expiration date. This session may be recorded or monitored. Hours of Operation are 7AM to 12AM ET.";
        var livePersonMsg6 = "Please do not share sensitive account information here, such as your security word or expiration date. This session may be recorded or monitored.";
        console.log("iFirstMessage" + data.context.session.BotUserSession.isFirstMessage);
        if (data.context.session.BotUserSession && !data.context.session.BotUserSession.isFirstMessage) {
            if (data.message === livePersonMsg1 || data.message === livePersonMsg2 || data.message === livePersonMsg3 || data.message === livePersonMsg4 || data.message === livePersonMsg5 || data.message === livePersonMsg6) {
                console.log("Inside the Message" + data.message);
                userMessage(data, callback);
            } else {
                data.context.session.BotUserSession.uuid = consoleFormatterUtil.generateUUID();
                data.context.session.BotUserSession.clientId = config.profile.clientId;
                data.context.session.BotUserSession.intentValue = "";
                data.context.session.BotUserSession.timestamp = 0;
                consoleFormatterUtil.printLog("info", data, "Setting the user First name" + JSON.stringify(data.context.session.BotUserSession.lastMessage));
                logger.info(data.context.session.BotUserSession.customerId + " - " + "Setting the user First name" + JSON.stringify(data.context.session.BotUserSession.lastMessage));
                data.context.session.BotUserSession.isFirstMessage = true;
                consoleFormatterUtil.printLog("info", data, "calling the BotProfile rest services");
                logger.info(data.context.session.BotUserSession.customerId + " - " + "calling the BotProfile rest services");
                if (data.context.session.BotUserSession.lastMessage) {
                    if (data.context.session.BotUserSession.lastMessage.channel === "liveperson") {
                        if (data.sendUserMessageUrl) {
                            data.context.session.BotUserSession.sendUserMessageUrl = data.sendUserMessageUrl;
                        }
                        if (data.sendBotMessageUrl) {
                            data.context.session.BotUserSession.sendBotMessageUrl = data.sendBotMessageUrl;
                        }
                        data.context.session.BotUserSession.lastMessage.messagePayload.profile.forEach(function (profile) {
                            if (profile.type === "personal") {
                                data.context.session.BotUserSession.lastMsgUsrName = profile.personal.firstname;
                            }
                            if (profile.type === "ctmrinfo") {
                                if (profile.info.customerId) {
                                    data.context.session.BotUserSession.customerId = profile.info.customerId;
                                }
                            }
                        });
                        var bizTokenDetails = getBizTokenDetails(data);
                        bizTokenDetails.then(function (bizTokenJSON) {
                            if (bizTokenJSON[0].bizToken) {
                                data.context.session.BotUserSession.bizToken = bizTokenJSON[0].bizToken;
                                data.context.session.BotUserSession.dcLocation = bizTokenJSON[0].dcLocation;
                                var accountProfileDetails = getAPIProfileDetails(bizTokenJSON[0].bizToken, "APS", bizTokenJSON[0].dcLocation, data);
                                accountProfileDetails.then(function (accProfileRes) {
                                    consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "Fetched getAccountProfileDetails");
                                    logger.info(bizTokenJSON[0].bizToken + " - " + data.context.session.BotUserSession.customerId + " - " + "Fetched getAccountProfileDetails");
                                    if (accProfileRes.cType) {
                                        data.context.session.BotUserSession.accountProfileServiceResponse = accProfileRes;
                                        consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, data.context.session.BotUserSession.accountProfileServiceResponse.cType);
                                        logger.info(data.context.session.BotUserSession.customerId + " - " + data.context.session.BotUserSession.accountProfileServiceResponse.cType);
                                        //To get CPS Details
                                        var customerProfileDetails = getAPIProfileDetails(bizTokenJSON[0].bizToken, "CPS", bizTokenJSON[0].dcLocation, data);
                                        customerProfileDetails.then(function (custProfileRes) {
                                            consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "Fetched getCustomerprofileDetails");
                                            logger.info(data.context.session.BotUserSession.customerId + " - " + "Fetched getCustomerprofileDetails");
                                            if (custProfileRes.bankAccounts || custProfileRes.creditCardAccounts) {
                                                data.context.session.BotUserSession.customerProfileServiceResponse = custProfileRes;
                                            } else {
                                                data.context.session.BotUserSession.customerProfileServiceResponse = null;
                                                consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "No Customer Profile Data available");
                                                logger.info(data.context.session.BotUserSession.customerId + " - " + "No Customer Profile Data available");
                                            }
                                            //To Get Rewards
                                            var rewardsDetails = getAPIProfileDetails(bizTokenJSON[0].bizToken, "REWARDS", bizTokenJSON[0].dcLocation, data);
                                            rewardsDetails.then(function (rewardsRes) {
                                                consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "Fetched rewards Details" + rewardsRes);
                                                logger.info(data.context.session.BotUserSession.customerId + " - " + "Fetched rewards Details" + rewardsRes);
                                                data.context.session.BotUserSession.rewardsServiceResponse = rewardsRes;
                                                //To Get Routing Details                                                 
                                                if (accProfileRes.bankAccounts && accProfileRes.bankAccounts.length) {
                                                    var acctNumbers = [];
                                                    for (var i = 0; i < accProfileRes.bankAccounts.length; i++) {
                                                        acctNumbers.push(accProfileRes.bankAccounts[i].accountNumber);
                                                    }
                                                    var routingDetails = getABARoutingDetails(bizTokenJSON[0].bizToken, acctNumbers, bizTokenJSON[0].dcLocation, data);
                                                    consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "RoutingDetails " + JSON.stringify(routingDetails));
                                                    logger.info(data.context.session.BotUserSession.customerId + " - " + "RoutingDetails " + JSON.stringify(routingDetails));
                                                    if (JSON.stringify(routingDetails) === "{\"isFulfilled\":false,\"isRejected\":false}") {
                                                        consoleFormatterUtil.printBizTokenLog("info", data, "Routing API  returend error");
                                                        logger.info(data.context.session.BotUserSession.customerId + " - " + "Routing API  returend error");
                                                        if (data.message.length > 80) {
                                                            data.message = "Agent Transfer";
                                                            consoleFormatterUtil.printLog("info", data, "More than 80 characters input.. Transferrring to agent");
                                                            logger.info(data.context.session.BotUserSession.customerId + " - " + "More than 80 characters input.. Transferrring to agent");
                                                            return sdk.sendBotMessage(data, callback);
                                                        } else {
                                                            userMessage(data, callback);
                                                        }
                                                    } else {
                                                        routingDetails.then(function (routingRes) {
                                                            consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "Fetched routing Details");
                                                            logger.info(data.context.session.BotUserSession.customerId + " - " + "Fetched routing Details");
                                                            data.context.session.BotUserSession.routingServiceResponse = routingRes;
                                                            if (data.message.length > 80) {
                                                                data.message = "Agent Transfer";
                                                                consoleFormatterUtil.printLog("info", data, "More than 80 characters input.. Transferrring to agent");
                                                                logger.info(data.context.session.BotUserSession.customerId + " - " + "More than 80 characters input.. Transferrring to agent");
                                                                return sdk.sendBotMessage(data, callback);
                                                            } else {
                                                                userMessage(data, callback);
                                                            }
                                                        });
                                                    }
                                                } else {
                                                    consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "NO Bank Accounts to pull");
                                                    logger.info(data.context.session.BotUserSession.customerId + " - " + "NO Bank Accounts to pull");
                                                    data.context.session.BotUserSession.routingServiceResponse = null;
                                                    if (data.message.length > 80) {
                                                        data.message = "Agent Transfer";
                                                        consoleFormatterUtil.printLog("info", data, "More than 80 characters input.. Transferrring to agent");
                                                        logger.info(data.context.session.BotUserSession.customerId + " - " + "More than 80 characters input.. Transferrring to agent");
                                                        return sdk.sendBotMessage(data, callback);
                                                    } else {
                                                        userMessage(data, callback);
                                                    };
                                                }
                                            });
                                        });
                                    } else {
                                        consoleFormatterUtil.printBizTokenLog("info", data, bizTokenJSON[0].bizToken, "NO Account Porfile Data available.. Need to backup a second");
                                        logger.info(data.context.session.BotUserSession.customerId + " - " + "NO Account Porfile Data available.. Need to backup a second");
                                        data.context.session.BotUserSession.isFirstMessage = false;
                                        data.message = "API Call Failure Message";
                                        return sdk.sendBotMessage(data, callback);
                                    }
                                });
                            } else {
                                consoleFormatterUtil.printLog("info", data, "NO BizToken Available available.. Transferrring to agent");
                                logger.info(data.context.session.BotUserSession.customerId + " - " + "NO BizToken Available available.. Transferrring to agent");
                                data.message = "API Call Failure Message";
                                return sdk.sendBotMessage(data, callback);
                            }
                        });
                    } else {
                        if (data.message.length > 80) {
                            data.message = "Agent Transfer";
                            consoleFormatterUtil.printLog("info", data, "More than 80 characters input.. Transferrring to agent");
                            logger.info(data.context.session.BotUserSession.customerId + " - " + "More than 80 characters input.. Transferrring to agent");
                            return sdk.sendBotMessage(data, callback);
                        } else {
                            userMessage(data, callback);
                        }
                    }
                }

            }
        } else {
            if (data.message.length > 80) {
                data.message = "Agent Transfer";
                consoleFormatterUtil.printLog("info", data, "More than 80 characters input.. Transferrring to agent");
                logger.info(data.context.session.BotUserSession.customerId + " - " + "More than 80 characters input.. Transferrring to agent");
                return sdk.sendBotMessage(data, callback);
            } else {
                if (data.sendUserMessageUrl) {
                    data.context.session.BotUserSession.sendUserMessageUrl = data.sendUserMessageUrl;
                }
                if (data.sendBotMessageUrl) {
                    data.context.session.BotUserSession.sendBotMessageUrl = data.sendBotMessageUrl;
                }
                userMessage(data, callback);
            }
        }
    },
    on_bot_message: function (requestId, data, callback) {
        consoleFormatterUtil.printLog("debug", data, "on bot message " + JSON.stringify(data.message));
        logger.info(data.context.session.BotUserSession.customerId + " - on bot message " + JSON.stringify(data.message));
        //console.log("Data Message",JSON.stringify(data));
        let cText = false;
        if (!data.message) {
            consoleFormatterUtil.printLog("debug", data, "***********Empty speech bubble from FAQ***************");
            logger.debug(data.context.session.BotUserSession.cutsomerId + " - " + "***********Empty speech bubble from FAQ***************");
            return callback;
        } else if (data.message == "\n") {
            consoleFormatterUtil.printLog("debug", data, "***********Empty speech bubble from FAQ***************");
            logger.debug(data.context.session.BotUserSession.customerId + " - " + "***********Empty speech bubble from FAQ***************");
            return callback;
        } else if (data.message == "<br>") {
            consoleFormatterUtil.printLog("debug", data, "***********Empty speech bubble from FAQ***************");
            logger.debug(data.context.session.BotUserSession.customerId + " - " + "***********Empty speech bubble from FAQ***************");
            return callback;
        }

        if (data.context.message_tone) {
            data.context.message_tone.forEach(function (tone) {
                if (tone.tone_name === "angry" && tone.level >= 2.5) {
                    //cText= true;                    
                    consoleFormatterUtil.printLog("debug", data, "Inside agent for anger tone");
                    logger.debug(data.context.session.BotUserSession.customerId + " - " + "Inside agent for anger tone");
                    //data.message = "Agent transfer";
                    data.message = "TransferOnSentimentAnalysis";
                    //let _data = _.clone(data);
                    //console.log(JSON.stringify(_data.message));
                    //return sdk.sendBotMessage(_data, callback);
                    //console.log(JSON.stringify(data));
                    //sdk.sendBotMessage(data, callback);
                    cText = true;
                }
            });
        }

        if (cText) {
            let _data = _.clone(data);
            _data.overrideMessagePayload = changeText(data, data.channel.type);
            return sdk.sendUserMessage(_data, callback);
        }
        if (data.message === 'hello') {
            data.message = 'The Bot says hello!';
        }
        //consoleFormatterUtil.printLog("debug",data,"on bot message", JSON.stringify(data.overrideMessagePayload));

        //return sdk.sendUserMessage(data, callback);

        var visitorId = _.get(data, 'channel.from');
        if (!queues[visitorId]) {
            var queue = new TimedQueue(1000);
            queue.on('expired', function (data) {
                //console.log('expired:' + Date.now(), data.message);
                sdk.sendUserMessage(data);
            });
            queues[visitorId] = queue;
        }

        queues[visitorId].enqueue(data);
        if (data.context.intent) {

            if (data.context.intent === data.context.session.BotUserSession.intentValue && data.context.userInputs.originalInput.timestamp > data.context.session.BotUserSession.timestamp) {
                console.log("Before", JSON.stringify(data));
                var cloneData = _.cloneDeep(data);
                var taskName = "Agent Transfer";
                cloneData.metaInfo = {
                    nlMeta: {
                        isRefresh: true
                    }
                };
                data.message = taskName;
                sendBotMessage(cloneData).then(function () {
                    data.metaInfo = {
                        nlMeta: {
                            intent: taskName
                        },
                        matchedIntentType: "dialog",
                        taskName: taskName
                    };
                    console.log("After", JSON.stringify(data));
                    return sdk.sendBotMessage(data);
                });
                redisClient.set(visitorId, true, 'EX', 10); // this key will expire after 10 seconds

            } else {
                data.context.session.BotUserSession.intentValue = data.context.intent;
                data.context.session.BotUserSession.timestamp = data.context.userInputs.originalInput.timestamp;
                console.log("inside default bot message");
                //sdk.sendUserMessage(data, callback);
            }
        } else {
            console.log("Sending user message");
            //sdk.sendUserMessage(data, callback);
        }

        return callback;
    },
    on_webhook: function (requestId, data, componentName, callback) {
        console.log("on webhook", componentName, JSON.stringify(data));
        consoleFormatterUtil.printLog("info", data, "on webhook " + componentName + " " + JSON.stringify(data));
        logger.info(data.context.session.BotUserSession.customerId + " - " + "on webhook " + componentName + " " + JSON.stringify(data));
        //  console.log("data.context", data.context);
        if (componentName === 'One') {
            sdk.saveData(requestId, data)
                .then(function () {
                    //Place the order.
                    data.success = 'true';
                    callback(null, data);
                });
        } else if (componentName === 'One') {
            sdk.saveData(requestId, data)
                .then(function () {
                    placeOrder(requestId, data, {

                    });
                    callback(null, new sdk.AsyncResponse());
                });

        } else {
            console.log('Invalid API call');
            consoleFormatterUtil.printLog("info", data, "Invalid API call");
            logger.info(data.context.session.BotUserSession.customerId + " - " + "Invalid API call");
        }
    },
    on_agent_transfer: function (requestId, data, callback) {
        var botSkillId = data.context.session.BotUserSession.AgentSkillId;
        consoleFormatterUtil.printLog("debug", data, " Starting ******* Transfreed to Agent " + botSkillId);
        logger.debug(data.context.session.BotUserSession.customerId + " - " + " Starting ******* Transfreed to Agent " + botSkillId);
        if (!botSkillId) {
            botSkillId = config.livePerson.skillId
        }
        let agentDetails = [{
            "field": "ParticipantsChange",
            "type": "REMOVE",
            "role": "ASSIGNED_AGENT"
        }, {
            "field": "Skill",
            "type": "UPDATE",
            "skill": botSkillId
        }];
        data.message = '';
        data.metaInfo = {
            transferToAgent: true,
            agentDetails: agentDetails
        };
        data.baseUrl = data._originalPayload.baseUrl;
        data.callbackUrl = data._originalPayload.callbackUrl;
        data.sendUserMessageUrl = data._originalPayload.sendUserMessageUrl;
        console.log("data", JSON.stringify(data));
        data.toJSON = function () {
            return {
                __payloadClass: 'OnMessagePayload',
                requestId: requestId,
                botId: botId,
                sendUserMessageUrl: this.sendUserMessageUrl,
                context: this.context,
                channel: this.channel,
                message: this.message,
                agent_transfer: this.agent_transfer,
                baseUrl: this.baseUrl,
                metaInfo: this.metaInfo
            }
        };
        sdk.clearAgentSession(data, function (resp) {
            consoleFormatterUtil.printLog("info", data, " Transfreed to Agent " + botSkillId);
            logger.info(data.context.session.BotUserSession.customerId + " - " + " Transfreed to Agent " + botSkillId);
        });
        return sdk.sendUserMessage(data, callback);
    }
};


init();