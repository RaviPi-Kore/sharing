const HttpRequest = require('./HttpRequest')
const DomainService = require('./DomainService');
const ConsumerRequestConversation = require("./model/ConsumerRequestConversation");
const SetUserProfile = require("./model/SetUserProfile");
const Request = require("./model/Request");
const config = require("../config");
var _ = require('lodash');
const asyncForEach = require('async-foreach').forEach;

var redisClient = require("./../lib/RedisClient.js").createClient(config.redis);

//var _userTokenMap = {};


function authenticate(conversation) {
    return new Promise(function (resolve, reject) {
        return getAppJWT(conversation)
            .then((res) => {
                conversation.appJWT = res['access_token'];
                console.log("tes: " + JSON.stringify(res));
                return getConsumerJWS(conversation)
                    .then((res) => {
                        conversation.consumerJWS = res['token'];
                        resolve(conversation);
                    })
            });
    });
}

function getAppJWT(conversation) {
    return new Promise(function (resolve, reject) {
        const options = {
            headers: {
                'content-type': 'application/x-www-form-urlencoded'
            }
        };
        DomainService.getDomainByServiceName("sentinel", conversation.brandId).then((host) => {
            let url = `https://${host}/sentinel/api/account/${conversation.brandId}/app/token?v=1.0&grant_type=client_credentials&client_id=${config.liveperson.clientId}&client_secret=${config.liveperson.clientSecret}`
            HttpRequest.post(url, options, undefined).then(function (response) {
                resolve(response);
            })
        });
    });
}

function getConsumerJWS(conversation) {
    return new Promise(function (resolve, reject) {
        let options = {
            "headers": {
                'content-type': 'application/json',
                'Authorization': conversation.appJWT
            }
        };
        DomainService.getDomainByServiceName("idp", conversation.brandId).then((host) => {
            const body = { "ext_consumer_id": conversation.visitorId };
            let url = `https://${host}/api/account/${conversation.brandId}/consumer?v=1.0`
            HttpRequest.post(url, options, body).then(function (response) {
                resolve(response);
            })
        });
    });
}

function openConverstionHeaders(appJWT, consumerJWS) {
    console.log("appJWT: " + appJWT)
    return {
        'headers': {
            'content-type': 'application/json',
            'Authorization': appJWT,
            'x-lp-on-behalf': consumerJWS
        }
    };
}


async function getConversationId(response) {
    return new Promise(function (resolve, reject) {
        asyncForEach(response, async (res) => {
            try {
                if (res.body.hasOwnProperty("conversationId")) {
                    console.log("conversationId: " + res.body.conversationId)
                    resolve(res.body.conversationId);
                } else if (res.body.hasOwnProperty("result") && res.body.hasOwnProperty("convId")) {
                    resolve(res.body.result.convId);
                }
            } catch (err) {
                console.error("ERROR parsing notification JSON, the conversation ID cannot be found ", err);
            }
        });
    });
}

// function getConversationId(response) {
//     console.info(JSON.stringify(response));
//     const conversationId = "";
//     response.forEach(function (res) {
//         try {
//             if (res.body.hasOwnProperty("conversationId")) {
//                 return res.body.conversationId;
//             } else if (res.body.hasOwnProperty("result") && res.body.hasOwnProperty("convId")) {
//                 return res.body.result.convId;
//             }
//         } catch (err) {
//             console.error("ERROR parsing notification JSON, the conversation ID cannot be found ", err);
//         }
//     });
//     return conversationId;
// }

function getOpenConvRequestBody(conversation) {
    let requestBody = new ConsumerRequestConversation(
        "CUSTOM",
        "MESSAGING",
        conversation.brandId,
        conversation.skillId
    );
    let requestConversationPayload = new Request("req", "2,", "cm.ConsumerRequestConversation", requestBody);

    let setUserProfileBody = new SetUserProfile(
        conversation.firstName || "John",
        conversation.lastName || "Doe",
        conversation.gender || "MALE"
    );


    let attributes = {
        "ctype": conversation.ctype || "VIP",
        "cstatus": conversation.cstatus || "index.html",
        "customerId": conversation.customerId || "123456",
        "imei": conversation.imei|| "1234566",
        "lastPaymentDate": conversation.lastPaymentDate || {
            "day": 15,
            "month": 10,
            "year": 2014
        },
        "registrationDate": conversation.registrationDate || {
            "day": 23,
            "month": 5,
            "year": 2013
        }
    }

    let authenticatedData = {
        "authenticatedData": {
            "lp_sdes": [
                {
                    "type": "ctmrinfo",
                    "info": attributes
                },
                {
                    "type": "personal",
                    "personal": setUserProfileBody
                }
            ]
        }
    }
    let setUserProfilePayload = new Request("req", "1,", "userprofile.SetUserProfile", authenticatedData);

    return [setUserProfilePayload, requestConversationPayload];
}

function openConversationRequest(conversation) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", conversation.brandId).then((host) => {
            const options = openConverstionHeaders(conversation.appJWT, conversation.consumerJWS, conversation.features);
            const body = getOpenConvRequestBody(conversation);
            let url = `https://${host}/api/account/${conversation.brandId}/messaging/consumer/conversation?v=3`
            HttpRequest.post(url, options, body).then(function (response) {
                resolve(response);
            })
        });
    });
}

function sendMessageRequest(message) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", config.liveperson.accountId).then((host) => {
            redisClient.hget("tokens", message.body.dialogId, function (err, conversation) {
                console.log("sendMessageRequest conversation is: " + conversation);
                if (conversation) {
                    const options = openConverstionHeaders(JSON.parse(conversation).appJWT, JSON.parse(conversation).consumerJWS);
                    let url = `https://${host}/api/account/${config.liveperson.accountId}/messaging/consumer/conversation/send?v=3`
                    HttpRequest.post(url, options, message).then(function (response) {
                        resolve(response);
                    })
                } else {
                    console.log("there no tokens for this dailog: " + message.body.dialogId)
                }
            });
            //let conversation=redisClient.hget("tokens",)

        });
    });
}



function closeConversationRequest(message) {
    return new Promise(function (resolve, reject) {
        DomainService.getDomainByServiceName("asyncMessagingEnt", config.liveperson.accountId).then((host) => {
            //console.log("map is: "+JSON.stringify(_userTokenMap))

            redisClient.hget("tokens", message.body.conversationId, function (err, conversation) {
                console.log("conversation is: " + conversation);
                //let conversation = redisClient.hget("tokens", message.body.dialogId)
                if (conversation) {
                    const options = openConverstionHeaders(JSON.parse(conversation).appJWT, JSON.parse(conversation).consumerJWS);
                    let url = `https://${host}/api/account/${config.liveperson.accountId}/messaging/consumer/conversation/send?v=3`
                    HttpRequest.post(url, options, message).then(function (response) {
                        resolve(response);
                    })
                } else {
                    console.log("no tokens for this dialogId: " + message.body.dialogId)
                }
            })
        });
    });
}

module.exports = {
    openConversation: function (conversation) {
        return authenticate(conversation).then((res) => {
            return openConversationRequest(conversation).then((res) => {
                console.log("Response is: " + JSON.stringify(res))
                return getConversationId(res).then((conversationId) => {
                    console.log("conv: " + conversationId)
                    conversation.conversationId = conversationId;
                    conversation.isConvStarted = true;
                    console.log("conv: " + JSON.stringify(conversation))
                    redisClient.hset("tokens", conversationId, JSON.stringify(conversation))
                    return conversation;
                });

            });
        })
    },
    sendMessage: function (message) {
        return sendMessageRequest(message).then(res => {
            console.log("response is: " + JSON.stringify(res))
            return res;
        });
    },

    closeConversation: function (message) {
        return closeConversationRequest(message).then(res => {
            console.log("response is: " + JSON.stringify(res))
            return res;
        });
    }
}
