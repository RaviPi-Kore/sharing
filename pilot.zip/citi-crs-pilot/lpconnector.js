var sdk = require("./lib/sdk");
var Promise = sdk.Promise;
var config = require("./config");
const AgentService = require('./lp/AgentService')
const feedback = require('./feedback')
var redisClient = require("./lib/RedisClient.js").createClient(config.redis);
redisClient.config("SET", "notify-keyspace-events", "KExA");
var _ = require('lodash');
var botId = config.credentials.botId;
var botName = config.credentials.botName;
var cuProxy = require("./cuproxy");
var request = require('request-promise');


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}
var agentTransferText = ["Sorry I couldnÃ¢help. IÃ¢ connect you to a representative.", "I didnÃ¢mean to upset you. A representative is on the way to help. ", "Sorry, IÃ¢still pretty new to this. IÃ¢ get a representative for you.", "I apologize if I made you upset. IÃ¢connecting you to someone now."]

function changeText(data, channel) {
    var overrideMessagePayload = {
        body: JSON.stringify({
            "text": agentTransferText[Math.floor(Math.random() * agentTransferText.length)]
        }),
        isTemplate: true
    };
    return overrideMessagePayload;
}

async function shutdown(e) {
    let err = e;
    console.log('Shutting down application');
    try {
        console.log('Closing database module');
        //      await database.close();
    } catch (e) {
        console.error(e);
        err = err || e;
    }
    console.log('Exiting process');
    if (err) {
        process.exit(1); // Non-zero failure code
    } else {
        process.exit(0);
    }
}
async function startup() {
    console.log('Starting application');
    try {
        console.log('Initializing database module');
        cuProxy.callOAuthApi();
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}
startup();
process.on('SIGTERM', () => {
    console.log('Received SIGTERM');
    shutdown();
});
process.on('SIGINT', () => {
    console.log('Received SIGINT');
    shutdown();
});
process.on('uncaughtException', err => {
    console.log('Uncaught exception');
    console.error(err);
    shutdown(err);
});
/*

* OnUserMessage event handler

*/
function onUserMessage(requestId, data, cb) {
    // debug("user message", data);
    var visitorId = _.get(data, 'channel.from');
    redisClient.hget("users", visitorId, function (err, replay) {
        console.log(JSON.stringify(replay));
        let entry = JSON.parse(replay);
        if (entry) {
            redisClient.hset("data", entry.secured_session_id, JSON.stringify(data));
            if (data.message == "endAgentChat") {
                console.log('to agent clearsession');
                let closeMessageObj = {
                    "kind": "req",
                    "id": "1",
                    "type": "cm.UpdateConversationField",
                    "body": {
                        "conversationId": entry.secured_session_id, // this is converstionId/dialogId
                        "conversationField": {
                            "field": "ConversationStateField",
                            "conversationState": "CLOSE"
                        }
                    }
                }
                AgentService.closeConversation(closeMessageObj)
            } else { //check for live agent
                let messageObj = {
                    "kind": "req",
                    "id": "1",
                    "type": "ms.PublishEvent",
                    "body": {
                        "dialogId": entry.secured_session_id, // this is converstionId/dialogId
                        "event": {
                            "type": "ContentEvent",
                            "contentType": "text/plain",
                            "message": data.message // User message
                        }
                    }
                }
                return AgentService.sendMessage(messageObj)
                    .catch(function (e) {
                        console.error(e);
                        redisClient.hdel("data", entry.secured_session_id, function (err, res) {});
                        redisClient.hdel("users", visitorId, function (err, res) {});
                        return sdk.sendBotMessage(data, cb);
                    });
            }
        } else {
            return sdk.sendBotMessage(data, cb);
        }
    });
}

function connectToAgent(requestId, data, cb) {
    var visitorId = _.get(data, 'channel.channelInfos.from');
    if (!visitorId) {
        visitorId = _.get(data, 'channel.from');
    }
    try {
        var conversation = {};
        console.log(JSON.stringify(data.context.BotUserSession));
        if (data.context && data.context.BotUserSession && data.context.BotUserSession.lastMessage && data.context.BotUserSession.lastMessage.messagePayload.customData && data.context.BotUserSession.lastMessage.messagePayload.customData.attributes) {
            conversation = data.context.BotUserSession.lastMessage.messagePayload.customData.attributes;
        }
        conversation.brandId = config.liveperson.accountId;
        data.message = "I will transfer you to the next available agent. The estimated response time is 2 minutes. You can also log back on later to see the response and continue the conversation";
        setTimeout(function () {
            sdk.sendUserMessage(data, cb);
        }, 1000);
        conversation.visitorId = visitorId;
        return AgentService.openConversation(conversation)
            .then(function (res) {
                console.log("res is: " + JSON.stringify(res))
                let infoObj = {
                    secured_session_id: res.conversationId,
                    visitorId: visitorId,
                    last_message_id: -1
                };
                redisClient.hset("users", visitorId, JSON.stringify(infoObj))
                redisClient.hset("data", res.conversationId, JSON.stringify(data))
                getUserhistory(data).then(function (history) {
                    console.log(parse_cht)
                    var chat_message = "";
                    var msg_type = "";
                    for (i = 0; i < parse_cht.total; i++) {
                        var temp = parse_cht.messages[i].components[0].data.text;
                        var msg_type = parse_cht.messages[i].type;
                        if (msg_type == "incoming") {
                            msg_type = "Customer";
                        } else {
                            msg_type = "Bot"
                        }
                        if (!temp.includes("template")) {
                            console.log(temp)
                            if (IsJsonString(temp)) {
                                chat_message = chat_message + msg_type + "@ " + JSON.parse(temp).text + "\n\n";
                            } else {
                                chat_message = chat_message + msg_type + "@ " + temp + "\n\n";
                            }
                        } else {
                            var temp = JSON.parse(parse_cht.messages[i].components[0].data.text);
                            chat_message = chat_message + msg_type + "@ " + temp.payload.text + "\n\n";
                        }
                    }
                    let messageObj = {
                        "kind": "req",
                        "id": "1",
                        "type": "ms.PublishEvent",
                        "body": {
                            "dialogId": res.conversationId, // this is converstionId/dialogId
                            "event": {
                                "type": "ContentEvent",
                                "contentType": "text/plain",
                                "message": chat_message
                            }
                        }
                    }
                    return AgentService.sendMessage(messageObj)
                        .catch(function (e) {
                            console.error(e);
                            redisClient.hdel("data", res.conversationId, function (err, res) {});
                            redisClient.hdel("users", visitorId, function (err, res) {});
                            return sdk.sendBotMessage(data, cb);
                        });
                });
            });
    } catch (err) {
        console.log("Error occured while connecting to agents", err);
        redisClient.hdel("users", visitorId, function (err, res) {});
        let _data = _.clone(data);
        _data.message = "Error while connecting to the Agent, Please try again after sometime";
        sdk.clearAgentSession(_data);
        return sdk.sendBotMessage(_data, cb);
    }
}

function sendCustomUserMessage(data, message) {
    data.toJSON = function () {
        return {
            __payloadClass: 'OnMessagePayload',
            requestId: data.requestId,
            botId: data.botId,
            componentId: data.componentId,
            sendUserMessageUrl: data.sendUserMessageUrl,
            sendBotMessageUrl: data.sendBotMessageUrl,
            context: data.context,
            channel: data.channel,
            message: message
        };
    };
    console.log("Bot requestId is: " + data.requestId)
    return sdk.sendUserMessage(data);
}
/*

* OnAgentTransfer event handler

*/
function onAgentTransfer(requestId, data, callback) {
    connectToAgent(requestId, data, callback);
}

function lpNotification(notification) {
    console.log("req body: " + JSON.stringify(notification));
    let convId = getNotificationConversationId(notification);
    console.log(" conversationId is: " + convId)
    redisClient.hget("data", convId, function (err, replay) {
        var data = JSON.parse(replay);
        var visitorId = _.get(data, 'channel.channelInfos.from');
        if (!visitorId) {
            visitorId = _.get(data, 'channel.from');
        }
        console.log("visitorId is: " + visitorId)
        if (notification.body.changes[0].event && notification.body.changes[0].event.type &&
            notification.body.changes[0].event.type === "ChatStateEvent") {
            console.log("eee")
            if (notification.body.changes[0].event.chatState == "COMPOSING") {} else if (notification.body.changes[0].event.chatState == "ACTIVE") {}
        } else if (notification.body.changes[0].originatorMetadata &&
            notification.body.changes[0].originatorMetadata.role != "CONSUMER" && data) { // Other events are ChatStateEvent, AcceptStatusEvent
            if (notification.body.changes[0].event.message) {
                console.log(" conversationId is: " + convId + " visitorId " + visitorId)
                return sendCustomUserMessage(data, notification.body.changes[0].event.message);
            }
        } else if (notification.body.changes[0].result &&
            notification.body.changes[0].result.conversationDetails &&
            notification.body.changes[0].result.conversationDetails.state &&
            notification.body.changes[0].result.conversationDetails.state === "CLOSE") {
            console.log('chat_closed');
            redisClient.hdel("data", convId, function (err, res) {
                console.log("data deleted success: ", convId)
            });
            redisClient.hdel("users", visitorId, function (err, res) {
                console.log("user deleted success: ", visitorId)
            });
            data.message = "You are done with Agent, Now you are connected to Bot again";
            data.toJSON = function () {
                return {
                    __payloadClass: 'OnMessagePayload',
                    requestId: data.requestId,
                    botId: data.botId,
                    componentId: data.componentId,
                    sendUserMessageUrl: data.sendUserMessageUrl,
                    sendBotMessageUrl: data.sendBotMessageUrl,
                    context: data.context,
                    channel: data.channel,
                    message: "You are done with Agent, Now you are connected to Bot again"
                };
            };
            sdk.clearAgentSession(data);
            return sdk.sendUserMessage(data);
        } else {
            console.log("Ignore")
        }
    });
}

function getUserhistory(data) {
    console.info("getUserhistory", data.context.session.UserContext._id); // added by kranti
    if (data) {
        data.limit = 100;
        var data = {
            baseUrl: "https://bots.kore.ai/api/botsdk/stream/" + botId,
            userId: data.context.session.UserContext._id,
            limit: 1000
        };
        console.log("data is: " + JSON.stringify(data))
        if (data) {
            return sdk.getMessages(data, function (err, resp) {
                if (err) {
                    console.log(err);
                }
                var messages = resp.messages;
                console.log("response is: " + messages);
                // res.status(200);
                return messages;
            });
        } else {
            console.log("error")
        }
    }
}

function gethistory(req, res) {
    redisClient.hget("data", req.query.userId, function (err, replay) {
        var data = JSON.parse(replay);
        var visitorId = _.get(data, 'channel.channelInfos.from');
        if (!visitorId) {
            visitorId = _.get(data, 'channel.from');
        }
        console.log("visitorId is: " + visitorId)
        // var userId = req.query.userId;
        var data = {
            baseUrl: "https://bots.kore.ai/api/botsdk/stream/" + botId,
            userId: visitorId,
            limit: 1000
        };
        console.log("data is: " + JSON.stringify(data))
        if (data) {
            return sdk.getMessages(data, function (err, resp) {
                if (err) {
                    res.status(400);
                    return res.json(err);
                }
                var messages = resp.messages;
                console.log("response is: " + messages);
                res.status(200);
                return res.json(messages);
            });
        } else {
            var error = {
                msg: "Invalid user",
                code: 401
            };
            res.status(401);
            return res.json(error);
        }
    });
}

function getNotificationConversationId(notification) {
    //logger.debug(JSON.stringify(notification));
    const noConversationId = "";
    try {
        if (notification.body.changes[0].hasOwnProperty("conversationId")) {
            return notification.body.changes[0].conversationId;
        } else if (notification.body.changes[0].hasOwnProperty("result") && notification.body.changes[0].result.hasOwnProperty("convId")) {
            return notification.body.changes[0].result.convId;
        } else if (notification.body.changes[0].hasOwnProperty("dialogId")) {
            return notification.body.changes[0].dialogId;
        }
    } catch (err) {
        logger.error("ERROR parsing notification JSON, the conversation ID cannot be found ", err);
    }
    return noConversationId;
}

function getAccountDetails(data) {
    console.log("phoneNumber", data.context.session.BotUserSession.lastMessage.messagePayload.from.id);
    try {
        var rbody = {
            "phoneNumber": data.context.session.BotUserSession.lastMessage.messagePayload.from.id.replace("+1", "")
        }
        var options = {
            method: 'POST',
            body: rbody,
            url: config.accountApi.endPoint,
            json: true,
            headers: {
                'content-type': 'application/json',
                "countryCode": config.accountApi.countryCode,
                "businessCode": config.accountApi.businessCode,
                "channelId": config.accountApi.channelId,
                "client_id": config.accountApi.clientId,
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId
            }
        };
        console.log(" options:" + JSON.stringify(options));
        return request(options).then(function (res) {
            console.log(res);
            return res.accountDetailsList; // you can read response here
        }).catch(function (err) {
            console.log("Error while calling the account details", err);
            return [];
        });
    } catch (Err) {
        console.error("Error while calling the account details", Err);
        return [];
    }
}

function changePaylod(data, message) {
    var accountNumber;
    var isMultipleAccounts = false;
    if (data && data.context.session && data.context.session.BotUserSession) {
        if (data.context.session.BotUserSession.AccountNumber) {
            accountNumber = data.context.session.BotUserSession.AccountNumber;
        } else if (data.context.session.BotUserSession.accountDetailsList && data.context.session.BotUserSession.accountDetailsList.length) {
            if (data.context.session.BotUserSession.accountDetailsList.length == 1) {
                accountNumber = data.context.session.BotUserSession.accountDetailsList[0].accountNumber
            } else {
                isMultipleAccounts = true;
            }
        } else {
            console.log("No account Number", data);
        }
    }
    var overrideMessagePayload;
    if (accountNumber) {
        overrideMessagePayload = {
            body: JSON.stringify({
                "textmessage": message,
                "accountNumber": accountNumber,
                "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId
            }),
            isTemplate: true
        };

    } else {
        if (isMultipleAccounts) {
            overrideMessagePayload = {
                body: JSON.stringify({
                    "textmessage": message,
                    "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId
                }),
                isTemplate: true
            };
        } else {
            overrideMessagePayload = {
                body: JSON.stringify({
                    "textmessage": "Looks like no accountNumber is associted with this mobile number, Please contact customer care XXXX",
                    "siteId": data.context.session.BotUserSession.lastMessage.messagePayload.siteId
                }),
                isTemplate: true
            };
        }
    }
    return overrideMessagePayload;
}

module.exports = {
    botId: botId,
    botName: botName,
    on_user_message: function (requestId, data, callback) {
        console.log('data' + JSON.stringify(data.context.session.BotUserSession.lastMessage));
        if (data.context.session.BotUserSession.lastMessage.channel === "rtm") {
            let uuid = data.channel.type + "/" + data.channel.from;
            redisClient.set(uuid + ":data", JSON.stringify(data));
            if (redisClient.get(uuid)) {
                redisClient.del(uuid);
            }
        }
        if (data.context.session.BotUserSession.lastMessage.channel === "ivr") {
            if (data.context.session.BotUserSession.accountDetailsList) {
                return sdk.sendBotMessage(data, callback);
            } else {
                getAccountDetails(data).then((response) => {
                    if (response && response.length) {
                        data.context.session.BotUserSession.accountDetailsList = response;
                        return sdk.sendBotMessage(data, callback);
                    } else {
                        console.log("No accounts associted with this phone number", data.context.session.BotUserSession.lastMessage.messagePayload);
                        data.overrideMessagePayload = changePaylod(data, "");
                        return sdk.sendUserMessage(data, callback);
                    }
                });
            }
        } else {
            onUserMessage(requestId, data, callback);
        }
    },
    on_bot_message: function (requestId, data, callback) {
        // sdk.sendUserMessage(data, callback);
        if (data.message) {
            if (data._originalPayload.channel.type == "ivr") {
                if (IsJsonString(data.message)) {
                    var mesObj = JSON.parse(data.message);
                    if ("isTemplate" in mesObj) {
                        console.info("It is template type" + mesObj.text);
                        data.overrideMessagePayload = changePaylod(data, mesObj.text);
                    } else {
                        console.info("It is object type" + JSON.parse(data.message).textmessage);
                        if (JSON.parse(data.message).textmessage) {
                            data.overrideMessagePayload = changePaylod(data, JSON.parse(data.message).textmessage);
                        }
                    }
                } else {
                    console.info("It is string type" + data._originalPayload.channel.message);
                    data.overrideMessagePayload = changePaylod(data, data.message);
                }
            }
            return sdk.sendUserMessage(data, callback);
        } else {
            console.log("debug", "***********Empty speech bubble from FAQ***************");
            return callback;
        }
    },
    on_agent_transfer: function (requestId, data, callback) {
        console.log("Agent chat initaited")
        onAgentTransfer(requestId, data, callback);
    },
    lp_notification_event: function (notification) {
        console.log("Lp notification initiated :" + JSON.stringify(notification));
        lpNotification(notification);
    },
    get_history: function (req, res) {
        gethistory(req, res);
    },
    on_event: function (requestId, data, callback) {
        if (data.channel.type === 'rtm') {
            if (data.event.eventType === 'endFAQ') {
                console.log("End of dialog reached!!!!");
                let uuid = data.channel.type + "/" + data.channel.from;
                feedback(uuid, data, null);
                if (data.context.session.BotUserSession.rephraseCount) {
                    data.context.session.BotUserSession.rephraseCount = undefined;
                }
            }
            console.log("Displaying repharse count: ", data.context.session.BotUserSession.rephraseCount)
            if (data.event.eventType === 'endDialog' && !data.context.intent.includes("User Feedback") && !data.context.intent.includes("Welcome") && !data.context.intent.includes("Help") && !data.context.intent.includes("NoIntent")) {
                console.log("End of dialog reached!!!!");
                let uuid = data.channel.type + "/" + data.channel.from;
                feedback(uuid, data, null);
            }
            console.log("on_event --> Event : ", data.event, data.context.intent);
            return callback(null, data);
        }
    }
};