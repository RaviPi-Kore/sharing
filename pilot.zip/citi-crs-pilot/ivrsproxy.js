var request = require("request");
var config = require("./config");

function IVRSProxy(req, res) {
    console.log("Request is: " + JSON.stringify(req.body) + " headers " + JSON.stringify(req.headers));
    try {
        let auth = req.headers['authorization'];
        if (auth) {
            if (!(req.body.to && req.body.to.id)) {
                return res.status(400).jsonp({ "code": "Missing Parameters", "message": "Bot Id is missing" })
            }

            if (!(req.body.from && req.body.from.id)) {
                return res.status(400).jsonp({ "code": "Missing Parameters", "message": "From mobile number is missing" })
            }

            if (!(req.body.from && req.body.from.id)) {
                return res.status(400).jsonp({ "code": "Missing Parameters", "message": "From mobile number is missing" })
            }
            if(!req.body.accountNumber){
                return res.status(400).jsonp({ "code": "Missing Parameters", "message": "AccountNumber number is missing" })
            }
            var options = {
                method: 'POST',
                url: config.kore.api,
                body: req.body,
                json: true,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': req.headers['authorization']
                }
            };
            console.log("options are ", options);
            request(options, function (error, response, body) {
                if (!error) {
                    console.log('Kore response [' + response.statusCode + '] body:  ' + body);
                    // need to implement the logic to call the CU API's
                    res.status(200).jsonp({ "code": "ok" })
                } else {
                    console.log('Error happened: ' + error);
                    res.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" })
                }
            });
        } else {
            res.status(401).jsonp({ "code": "UNAUTHORIZED", "message": "Authorization credentials are missing or invalid" })
        }
    } catch (err) {
        console.log("eror" + err);
        res.status(500).jsonp({ "code": "INTERNAL SERVER ERROR", "message": "The request failed due to an internal error/server unavailability" })
    }
}

module.exports = IVRSProxy;