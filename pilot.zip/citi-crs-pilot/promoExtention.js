const config = require("./config");
const sql = require('mssql')



var dbConfig = {
    user: 'sa',
    password: 'Ravi@123',
    server: 'localhost', // You can use 'localhost\\instance' to connect to named instance
    database: 'TestDB'
}

function promoExtentionApi() {
    //console.log("promoExtentionApi", req);
    try {
        sql.connect(dbConfig).then(pool => {
            return pool.request()
                .input('AccountNumber', sql.VarChar(16), "6035320000794551")
                .input('TransactionDate', sql.Date, "05/12/2019")
                .input('TransactionAmount', sql.Money, "45.00")
                .input('LengthOfPromo', sql.Int, 18)
                .execute('dbo.InsertReferralsSMS4',(err, result) => {
                    // ... error checks
             
                    console.log(result)
                })
        }).then(result => {
            console.log(result)
        }).catch(err => {
            console.error("Error while excuting the stored procedure", err)
        })
    } catch (Err) {
        console.log("Error while excuting the sql query", Err);
    }

}

promoExtentionApi();