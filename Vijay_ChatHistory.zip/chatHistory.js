var jsonexport    = require('jsonexport');
var express       = require('express');
var bodyParser    = require('body-parser');
var app           = express();
var server        = require('http').Server(app);
var _             = require('lodash');
var fs            = require('fs');
var request = require('request-promise');
var timezone      = require("moment-timezone");
var Promise = require('bluebird').config({warnings: {wForgottenReturn: false}});;
var config = require("./config");
var token = config.token;
var environment = config.environment;
var accountid = config.accountid;
var orgId = config.orgId;
var adminUserId = config.adminUserId;
var head = {
    accept: 'application/json',
    'content-type': 'application/json;charset=UTF-8',
    authorization: 'bearer '+token,
    'requester-type': 'admin',
    origin: environment,
    accountid: accountid
};
var fromDate = config.fromDate;
var toDate = config.toDate;

var body          = '{"streamIds":["st-daf17b79-1646-5d15-9b31-7a8688ebc423"]}';

function getChatHistory(){ 
	var options = {
        method: 'POST',
        url: 'https://'+environment+'/api/1.1/organization/'+orgId+'/botChatHistory',
        qs:
            { from: fromDate,
                to: toDate
            },
        headers: head,
        body: body
    };
    request(options). then(function (body) {
        if(typeof body === "string"){
            body = JSON.parse(body);
        }
		console.log("Body@@@@@", body);
		//console.log("Response!!!!!", response);
        var userIds = _.uniqBy(body.result,'userId');
        var chatHistoryP = Promise.map(userIds, function(user){
			console.log(user.userId);
            var options1 = { method: 'GET',
                url: 'https://'+environment+'/api/1.1/users/'+adminUserId+'/builder/streams/'+user.streamId+'/kora/logs',
                qs:
                    { 
						userId: user.userId,
                        from: fromDate,
                        to: toDate
                    },
                headers: head
            };
            return new Promise (function (resolve, reject) {
                request(options1).then(function (res) {
                    var chats = [];
					console.log("Body2 !!!!! ", res);
                    var log = JSON.parse(res).koralogs;
                    var text;
                    for (var y in log) {
                        if(log[y].components[0]&&log[y].components[0].data&&log[y].components[0].data.text){
                            text = log[y].components[0].data.text;
                        }else{
                            text = undefined;
                        }
                        var msg = text;
                        var obj = {};
                        obj.type  = log[y].type;
                        obj.botId  = log[y].botId;
                        obj.userId  = user.userId;
                        obj.timeStamp  = timezone(log[y].createdOn).utcOffset(330).format('YYYY-MM-DDTHH:mm:ss')+' IST';
                        obj.channel  = log[y].channels[0].type;
                        obj.message  = msg?msg.trim():"";
                        if (text) {
                            chats.push(obj);
                        }
                    }
                    resolve(chats);
                });
            });
        })
        chatHistoryP.then(function(results){
            /*if (error) {
                res.send(error);
            }*/

            jsonexport(results,function(err, csv){
                if(err) return console.log(err);
                console.log("Downloading CSV file");

                fs.writeFileSync("report.csv", csv);
                //res.download("report.csv");
            });
        })
    }
	);
}

getChatHistory();