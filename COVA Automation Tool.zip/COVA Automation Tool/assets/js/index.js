
var counter = 0;
var testcases = {}
var finalResult;

//random.innerHTML = memes[Math.floor(Math.random() * memes.length)];

/* Time */

var deviceTime = document.querySelector('.status-bar .time');
var messageTime = document.querySelectorAll('.message .time');

deviceTime.innerHTML = moment().format('h:mm');

setInterval(function () {
    deviceTime.innerHTML = moment().format('h:mm');
}, 1000);

for (var i = 0; i < messageTime.length; i++) {
    messageTime[i].innerHTML = moment().format('h:mm A');
}

/* Message */

//var form = document.querySelector('.conversation-compose');
var conversation = document.querySelector('.conversation-container');

//form.addEventListener('submit', newMessage);

$(document).ready(function () {
    $("span#siteId").text(getQueryStringValue("siteId").toUpperCase());
    $("#sendbutton").on("click", function () {
        newMessage();
    });
});

$('#userInput').keypress(function (e) {
    if (e.which == 13) {
        newMessage();
    }
});

function newMessage() {
    var input = document.getElementById("userInput").value;
    if (input) {
        var message = buildMessage(input);
        conversation.appendChild(message);
        //animateMessage(message);
        makeApiCall(input)
    }
    document.getElementById('userInput').value = ''
    conversation.scrollTop = conversation.scrollHeight;
    //e.preventDefault();
}

function getQueryStringValue(key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

function excuteTestCase(inputs, inputData) {
    setTimeout(() => {
        var i = 0;
        var l = inputs.input.length;
        (function iterator() {
            console.log(inputs.input[i]);
            inputData["msg"] = inputs.input[i];
            inputData["expectedOutPut"] = inputs.output[i];
            //var input = document.getElementById("userInput").value;
            var message = buildMessage(inputs.input[i]);
            conversation.appendChild(message);
            conversation.scrollTop = conversation.scrollHeight;
            excuteApiCall(inputData)
            if (++i < l) {
                setTimeout(iterator, 20000);
            } else {
                console.log(JSON.stringify(finalResult));
                return new Promise(resolve)
            }
        })();
    });
}
async function excuteTestCases() {
    var inputData = {
        "phoneNumber": testcases.phoneNumber,
        "siteId": testcases.siteId,
        "url": environments[testcases.env].url,
        "token": environments[testcases.env].token
    }
    $("span#siteId").text(testcases.siteId);
    console.log(JSON.stringify(inputData));
    var loopKeys = Object.keys(testcases.senarios);

    let items = loopKeys;
    let a = 0;
    await new Promise(async (resolve, reject) => {
        let funSync = async () => {
            await excuteTestCase(testcases.senarios[items[a]], inputData)
            a++;
            if (a == items.length) {
                resolve();
            }
            else {
                funSync();
            }
        }
        funSync();
    })
    // for (const l of loopKeys) {
    //     await excuteTestCase(testcases.senarios[l], inputData)
    // };
    console.log("Final result: " + JSON.stringify(finalResult));
}

// let items = YourArray;
// let i = 0;
// await new Promise(async (resolve, reject) => {
//     try {
//         if (items.length == 0) return resolve();
//         let funSync = async () => {
//             await yourASyncFunctions(items[i].doAnything);
//             i++;
//             if (i == items.length) resolve();
//             else funSync();
//         }
//         funSync();
//     } catch (e) {
//         reject(e);
//     }
// });




function excuteApiCall(inputData) {
    var body = {
        "from": {
            "id": "+1" + inputData.phoneNumber + "@" + inputData.siteId
        },
        "to": {
            "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
        },
        "message": {
            "text": inputData.msg
        },
        "session": {
            "new": true
        },
        "siteId": inputData.siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + inputData.phoneNumber + "_" + inputData.siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    $.ajax({
        url: inputData.url,
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": inputData.token,
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    result["actualOutput"] = msg
                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                result["actualOutput"] = JSON.parse(responseText).text
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                result["actualOutput"] = msg
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
            if (result.expectedOutPut && result.expectedOutPut !== "@@@@" && result.actualOutput && result.actualOutput.includes(result.expectedOutPut)) {
                //console.log("Pass For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
                result["status"] = "pass";
                //}
            } else if (result.expectedOutPut === "@@@@") {
                result["status"] = "pass";
                //console.log("Pass For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
            } else {
                result["status"] = "fail";
                //console.log("Failed For" + uuid + "__Actual Output: " + botResponseText + " expected outPut: " + expectedOutPut);
            }
            finalResult.push(result);
        },
        error: function () {
            console.log("error");
        }
    });
}

function makeApiCall(queryString) {

    //var type = getQueryStringValue("type").toLocaleLowerCase();
    var siteId = getQueryStringValue("siteId").toLocaleLowerCase();
    var phoneNumber = getQueryStringValue("phoneNumber")


    var body = {
        "from": {
            "id": "+1" + phoneNumber + "@" + siteId
        },
        "to": {
            "id": "st-5bda0ad1-6529-5279-948e-7d70bf790d80"
        },
        "message": {
            "text": queryString
        },
        "session": {
            "new": true
        },
        "siteId": siteId,
        "channelId": "SMSAG",
        "uuid": counter + "_" + phoneNumber + "_" + siteId + "_" + Math.round(new Date().getTime() / 1000)
    }
    counter = counter + 1;
    console.log(JSON.stringify(body));
    $.ajax({
        url: 'https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa',
        type: "POST",
        dataType: "json",
        headers: {
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU",
            "Content-Type": "application/json"
        },
        data: JSON.stringify(body),
        success: function (response) {
            console.log(response);
            var responseText = response.text;
            if (Array.isArray(responseText)) {
                responseText.forEach(function (element) {
                    console.log(" in Array " + element + " typeof element" + typeof element);
                    let msg;
                    if (IsJsonString(element)) {
                        msg = JSON.parse(element).textmessage;
                        if (msg.textmessage) {
                            msg = msg.textmessage;
                        }
                    } else if (typeof element === 'object') {
                        msg = element.textmessage;
                    } else {
                        msg = element;
                    }
                    let message = buildIncomingMessage(msg);
                    conversation.appendChild(message);
                    //animateMessage(message);

                });
            } else if (responseText instanceof Object) {
                console.log(" in object " + element);

                let message = buildIncomingMessage(JSON.parse(responseText).text);
                conversation.appendChild(message);
                //animateMessage(message);
            } else {
                console.log(" in default " + responseText + " type of: " + typeof responseText);
                let msg;
                if (IsJsonString(responseText)) {
                    msg = JSON.parse(responseText).textmessage;
                    if (!msg) {
                        msg = JSON.parse(responseText).text;
                    }
                } else {
                    msg = responseText;
                }

                let message = buildIncomingMessage(msg);
                conversation.appendChild(message);
                //animateMessage(message);
            };
            conversation.scrollTop = conversation.scrollHeight;
        },
        error: function () {
            console.log("error");
        }
    });
}

function buildMessage(text) {
    var element = document.createElement('div');
    element.classList.add('message', 'sent');
    element.innerHTML = text +
        '<span class="metadata">' +
        '<span class="sentTime">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}

function urlify(text) {
    var urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, function (url) {
        return '<a href="' + url + '">' + url + '</a>';
    })
}

var environments = {
    "DIT": {
        "url": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "token": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiYXBwSWQiOiJjcy1iODAxZDRlOS1iNTEwLTU0ZDYtOWNjNC0xNDJmZDhlN2NiMWQifQ.-Yoh1De6cltL3WFpN7T_95Y6n-0lt_n2dIKXjFdWatU"
    },
    "UAT": {
        "url": "https://b172935-vip.nam.nsroot.net/chatbot/hooks/st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "token": ""
    },

}


function buildIncomingMessage(text) {
    console.log('buildIncomingMessage: ' + text);
    //text = text.split("#").join("");
    text = text.split("\n").join("<br>");
    text = urlify(text);
    if (!text) {
        text = "Looks like I had a technical issue on my end and I need to back up a sec. What do you need help with?";
    }
    var element = document.createElement('div');
    element.classList.add('message', 'received');
    element.innerHTML = '<div>' + text + '</div>'
    '<span class="metadata">' +
        '<span class="time">' + moment().format('h:mm A') + '</span>' +
        '</span>';

    return element;
}


function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function animateMessage(message) {
    setTimeout(function () {
        var tick = message.querySelector('.tick');
        tick.classList.remove('tick-animation');
    }, 500);
}
var sampleInput = {

    "phoneNumber": "9729988092",
    "siteId": "PLCN_BESTBUY",
    "environment": "DIT",

    "happyPath": {


        "input": [

            // "ClearSession",

            "Discard all",

            // "Hi",

            //"1183",

            "make payment",

            "1183",

            "Yes",

            "4",

            "3",

            "3",

            "07/25/2020",

            "Yes",

            "Yes",

            "Yes",

            "6789"

        ],

        "output": [

            // "context",

            "discarding the task for now",

            //"*",

            // "Hi, I'm your virtual guide to ",

            // "@@@@",

            "Which account do you want to pay?",

            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",

            "It looks like",

            "Please enter the amount of payment greater than $1 in $xx.xx format",

            "When do you want to make a payment",

            "Please enter a valid date in MM/DD/YYYY format",

            "We have your  account information from previous payments you have made",

            "Almost done: let's confirm the payment information and get your authorization to make the payment.",

            "If you choose to pay less than the Minimum Payment Due and do not make any additional payments, your account will be past due. You will also pay more in interest and it will take you longer to pay off your balance.\n\nTo avoid a late fee, schedule your Payment Date no later than your Payment Due Date.$$$$2/2. Would you like to continue and make a payment. \nText Y to make a payment\nText N to stop the payment communication.",

            "Do I have your authorization to take this payment now?\nPlease text the last 4 digits of the primary account holder's SSN to authorize this payment.\nText N if you do not authorize this payment.",

            "Your payment was successful $$$$ Is there anything else I can help you with today?"

        ]

    }

};
//   $('#jsonIde').jsonViewer(sampleInput);
new JsonEditor('#jsonIde', sampleInput);


$(document).ready(function () {
    $('#cova_run_btn').hide();

    // dropdown list onload
    $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases,#cova-testcases, #cova-validation').hide();

    // $(" #editor ").fadeTo(1, 0.25);
    // $(" #device ").fadeTo(1, 0.25);
    // $("#editor").children().prop('disabled',true);
    // document.getElementById("editor").disabled = true;

    $('#cova_form select[name="select-channel"]').change(function () {
        if ($('#cova_form select[name="select-channel"]').val() == 'web') {
            $('#cova-type, #cova-siteid, #cova-environment, #cova-testcases').show();

            $("#testcasesData").attr('disabled', false);

            $('#cova-usecases').hide();
        } else if ($('#cova_form select[name="select-channel"]').val() == '') {
            $('#cova-type, #cova-siteid, #cova-environment, #cova-phonenumber, #cova-phonenumber, #cova-usecases, #cova-testcases,#cova-validation').hide();

        } else if ($('#cova_form select[name="select-channel"]').val() == 'sms') {
            $('#cova-siteid, #cova-environment, #cova-phonenumber, #cova-usecases, #cova-testcases').show();

            $('#cova-type').hide();
            console.log("testcases up");
        }
    });
    $('#cova_form #cova-usecases select[name="select-usecases"]').change(function () {
        if ($('#cova_form select[name="select-usecases"]').val() == 'mannual') {
            $('#cova-validation').show();
            $("#testcasesData").attr('disabled', true);
        } else if ($('#cova_form select[name="select-usecases"]').val() == 'automation') {
            $('#cova-validation').hide();
            $("#testcasesData").attr('disabled', false);
        }
    });

});

$(document).ready(function () {
    $("#cova_details_tab").click(function () {
        console.log("The paragraph was clicked.");
        $("#cova_details_tab").hide();
        $('#cova_run_btn').show();
        // $("#editor").stop().fadeTo(1, 0.25);

    });
    $("#cova_previous_btn").click(function () {
        console.log("The previous was clicked.");
        // $("#editor").stop().fadeTo(1, 0.25);
        $('#cova_run_btn').hide();
        $("#cova_details_tab").show();
    });
});
$(document).ready(function () {
    $('#testcasesData').chosen();
});

function covaFormData() {
    //var channel = $('#channelData').val();
    var env = $('#environmentData').val();
    var siteidData = $('#siteidData').val();
    var phoneNumber = $('#phoneNumber').val();
    var senarios = {};
    var selectedTestCases = Array.from(document.getElementById("testcasesData").options).filter(option => option.selected).map(option => option.value);

    for (var tc of selectedTestCases) {
        let obj = {
        }
        obj[tc] = testCasesConfig[tc]
        senarios = Object.assign(senarios, obj)
    }

    testcases = {
        "phoneNumber": phoneNumber,
        "siteId": siteidData,
        "env": env,
        "senarios": senarios
    }

    new JsonEditor('#jsonIde', testcases);
}
var select = document.getElementById("testcasesData");
//var testcases = ["happy path", "Account_selection_1x to SSN", "Account_selection_2x", "Payment consent confirmaton_1x to SSN_Successful payment", "Payment consent confirmation_2x", "Amount options_1x to SSN", "Amount options_2x", "Enter amount_1x to SSN", "Enter amount_2x", "Payment date options_1x to SSN", "Payment date options_2x", "Enter date_1x to SSN", "Enter date_2x", "Payment Source Confirmation__No_end flow", "Single Payment Source Confirmation_1x to SSN", "Single Payment Source Confirmation_2x", "Multiple Payment Source_1x to SSN", "Multiple Payment Source_1x to SSN", "Payment authorization confirmation_1x to SSN", "Payment authorization confirmation_2x", "Change information_1x to SSN", "Change information_2x", "Change information_Date_SSN", "Change information_Date_2x", "Change information_PaymentSource(Multiple payment sources)_SSN", "Change information_PaymentSource_2x", "Change information_Amount_SSN", "Change information_Amount_2x", "Change information_StopPayment", "SSN_1x, SSN_2x", "SameDayPaymentReached_Date Options_1x", "No Outstanding balance", "Less than minimum payment validation_amount_1x to SSN", "More than outstanding balance", "No payment source", "Schedule payment morethan 45 days", "Multiple validation errors(More than outstanding balance and More than 45 days)"];

var testcases = ["happyPath", "ValidationError_Schedule_payment_morethan_45_days", "ValidationError_Multiple_validation_errors"]
// Optional: Clear all existing options first:
select.innerHTML = "";
// Populate list with options:
for (var i = 0; i < testcases.length; i++) {
    var opt = testcases[i];
    select.innerHTML += "<option value=\"" + opt + "\">" + opt + "</option>";
}


var testCasesConfig = {
    "happyPath": {
        "input": [
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "07/15/2020",
            "1",
            "yes",
            "6789"
        ],
        "output": [
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 07/15/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment.",
            "Thank you! Your payment was scheduled successfully. Your confirmation number is: 420168656641713. You can save this message for your records. \n\nEnrolling in AutoPay would save you time in the future. Click the link below to register\npay.homedepotconsumer.accountonline.com\n\nIs there anything else I can help you with today?"
        ]
    },
    "ValidationError_Schedule_payment_morethan_45_days": {
        "input": [
            "pay",
            "8098",
            "yes",
            "4",
            "2",
            "3",
            "09/20/2020",
            "1",
            "yes",
            "3",
            "07/20/2020",
            "yes"
        ],
        "output": [
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 07/20/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You can schedule payments between today and 45 days in the future. Please type a date [MM/DD/YYYY] within 45 days from today.\n\nWhen do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $2.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 09/20/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Do I have your authorization to schedule this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment.\n Text N if you do not authorize this payment."

        ]
    },

    "ValidationError_Multiple_validation_errors": {
        "input": [
            "pay",
            "8098",
            "yes",
            "4",
            "10000",
            "3",
            "09/20/2020",
            "1",
            "yes"

        ],
        "output": [
            "Which account do you want to pay?  Please text\n#1-Account ending in 9994\n#2-Account ending in 7935\n#3-Account ending in 8098\n#4-Account ending in 0222\n#5-Account ending in 6591\n#6-Account ending in 8310\n#7-Account ending in 0198\n#8-Account ending in 0214",
            "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",
            "It looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",
            "Please enter the amount of payment greater than $1 in $xx.xx format",
            "When do you want to make a payment? \n            Text 1 - Due Date 08/02/2020\n            Text 2 - Today 07/14/2020\n         Text 3 - A different date",
            "Please enter a valid date in MM/DD/YYYY format",
            "We have your account information from previous payments you have made\nWhich account do you want to use for your payment?  Please text #\n1- Account ending in 3232\n2- Account ending in 6789",
            "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/14/2020 and you are agreeing to a one-time payment of $10000.00 towards your The Home Depot® Consumer Credit Card ending in 8098, from your bank account ending in 3232 posting on 09/20/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",
            "Hmm.. You can schedule payments between today and 45 days in the future. Please type a date [MM/DD/YYYY] within 45 days from today.\n\nHmm.. You have exceeded the payment amount that can be scheduled for this account. Your maximum amount is the current balance.\n\nIt looks like:\nYour Minimum Due is $0.00\nYour Last Statement Balance was $13492.46\nYour Current Balance is $2000.00\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount"
        ]
    }
}

var covaTableData = [
    {

        "Input": "Discard all",

        "ExpectedOutPut": "discarding the task for now",

        "ActualOutput": "Ok, I'm discarding the task for now. We can start over whenever you're ready.\n",

        "status": "pass"

    },

    {

        "Input": "make payment",

        "ExpectedOutPut": "Which account do you want to pay?",

        "ActualOutput": "Which account do you want to pay?  Please text\n#1-Account ending in 1183\n#2-Account ending in 4540\n#3-Account ending in 5740\n#4-Account ending in 4573\n#5-Account ending in 0147\n",

        "status": "pass"

    },

    {

        "Input": "1183",

        "ExpectedOutPut": "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?",

        "ActualOutput": "Before we begin, you should know that your account information, including last statement balance, current balance and minimum payment due, will be displayed on this device and any other device where you receive text messages. Do you want to continue and allow this information to be displayed?\n",

        "status": "pass"

    },

    {

        "Input": "Yes",

        "ExpectedOutPut": "It looks like",

        "ActualOutput": "It looks like:\nYour Minimum Due is $41.85\nYour Last Statement Balance was $131.50\nYour Current Balance is $129.35\n\nWhat type of payment would you like to make?\nText 1 for Minimum Due\nText 2 for Last Statement Balance\nText 3 for Current Balance\nText 4 for Other Amount",

        "status": "pass"

    },

    {

        "Input": "4",

        "ExpectedOutPut": "Please enter the amount of payment greater than $1 in $xx.xx format",

        "ActualOutput": "Please enter the amount of payment greater than $1 in $xx.xx format",

        "status": "pass"

    },

    {

        "Input": "3",

        "ExpectedOutPut": "When do you want to make a payment",

        "ActualOutput": "When do you want to make a payment? \n            Text 1 - Due Date 07/20/2020\n            Text 2 - Today 07/07/2020\n            Text 3 - A different date",

        "status": "pass"

    },

    {

        "Input": "3",

        "ExpectedOutPut": "Please enter a valid date in MM/DD/YYYY format",

        "ActualOutput": "Please enter a valid date in MM/DD/YYYY format",

        "status": "pass"

    },

    {

        "Input": "07/25/2020",

        "ExpectedOutPut": "We have your  account information from previous payments you have made",

        "ActualOutput": "We have your  account information from previous payments you have made\n    Is the account ending with 7890 the account you want to use? \n    Text Y to make a payment from this account\n    Text N to stop the payment communication.",

        "status": "pass"

    },

    {

        "Input": "Yes",

        "ExpectedOutPut": "Almost done: let's confirm the payment information and get your authorization to make the payment.",

        "ActualOutput": "Almost done: let's confirm the payment information and get your authorization to make the payment. To confirm, today is 07/07/2020 and you are agreeing to a one-time payment of $3.00 towards your My Best BuyÂ® VisaÂ® Gold Card ending in 1183, from your bank account ending in 7890 posting on 07/25/2020\n\nYou may cancel or change this payment online or by calling us at the number on the back of your card before 5:00 pm Eastern time on the day of your scheduled payment.\n\nText Y if the payment information above is correct\nText N to make changes",

        "status": "pass"

    },

    {

        "Input": "Yes",

        "ExpectedOutPut": "If you choose to pay less than the Minimum Payment Due and do not make any additional payments, your account will be past due. You will also pay more in interest and it will take you longer to pay off your balance.\n\nTo avoid a late fee, schedule your Payment Date no later than your Payment Due Date.$$$$2/2. Would you like to continue and make a payment. \nText Y to make a payment\nText N to stop the payment communication.",

        "ActualOutput": "2/2. Would you like to continue and make a payment. \n        Text Y to make a payment \n        Text N to stop the payment communication.\n",

        "status": "fail"

    },

    {

        "Input": "Yes",

        "ExpectedOutPut": "Do I have your authorization to take this payment now?\nPlease text the last 4 digits of the primary account holder's SSN to authorize this payment.\nText N if you do not authorize this payment.",

        "ActualOutput": "Do I have your authorization to take this payment now? \n  Please text the last 4 digits of the primary account holder's SSN to authorize this payment. \n Text N if you do not authorize this payment.",

        "status": "fail"

    }

];
                $("#dataTable tr:has(td)").remove();
				var table = $("#dataTable");
				for(let i=0; i < covaTableData.length; i++){
                    var row = $("<tr></tr>").appendTo(table);
                    $("<td>"+(i+1)+"</td>").appendTo(row);
					$("<td></td>").text(covaTableData[i].Input).appendTo(row);
					$("<td></td>").text(covaTableData[i].ExpectedOutPut).appendTo(row);
                    $("<td></td>").text(covaTableData[i].ActualOutput).appendTo(row);
                    if(covaTableData[i].status === "pass"){
                        $("<td class='passData'></td>").text(covaTableData[i].status.toUpperCase()).appendTo(row);
                    } else{
                        $("<td class='failData'></td>").text(covaTableData[i].status.toUpperCase()).appendTo(row);
                    }
					
                }

                
