# Unit tests

Evemit is tested with [Unit.js](http://unitjs.com) and [Mocha](http://unitjs.com/guide/mocha.html).

---

Run the tests in the the console:
```sh
npm test
```

To execute the tests on client side, download the _test_ directory and go on _test/index.html_ file with your browser.