var jose = require('node-jose');

//RSA keypair
var result = {
    "kty": "RSA",
    "kid": "de668337-28f1-4086-8c52-5778944f9603",
    "n": "wgAbwhZC1zJnfZoga4UvHraacDXQIuzs7stD8804voVP-jNm4JPoqNjqqk5VWfwF_OxqYB98lk_5HEcIaX4WQdNgwE1Y3ddkkkcKUejBwSkZc_gqDSQwj-PBz16DNwvDQwlPGcl8_B-5JCe-bIAuYKqmUukULF3TzBHEjAjbLarO1NW9tF3mg8gX3c9nHvK31wA30fmEnAnPRP5DL-EThPFX1llRwLCiYWgpICbWrx7iMiXUBJfZMgqmbH5pzD7oTiIMrxhpmNND0qDxEWIjnjYM7ncHtcU3T-JLKrdH_GAdFSDhVZ7oLtJ6o9e8_RMlwLGV3M8kttY20eugBD_GZQ",
    "e": "AQAB"
}
//For testing purpose, below Kore API can be used to generate the above key holder.
//https://bots.kore.ai/api/1.1/users/u-c7150b6b-b170-510f-bdd5-fc3e4de5bf5b/builder/jwks
// Now pass JWE token to 'update' function below.
jose.JWE.createEncrypt({
    format: "compact",
    "fields": {
        "cty": "jwt"
    }
}, result).
update("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE1NTM3Nzk3MjgwNTksImV4cCI6MTU1Mzg2NjEyODA1OSwiYXVkIjoiaHR0cHM6Ly9pZHByb3h5LmtvcmUuYWkvYXV0aG9yaXplIiwiaXNzIjoiY3MtZmM4NWE0YmEtNzNiYi01MjdlLWExNjQtNDRlNDRmNDkxNzI5Iiwic3ViIjoiMjBlZDQxNjQtY2RkNi00MWQyLWJhNTItMmJhNzY2YzFmZDEiLCJpc0Fub255bW91cyI6ImZhbHNlIiwic2VjdXJlQ3VzdG9tRGF0YSI6eyJuYW1lIjoiUGV0ZXIiLCJhZ2UiOiIzOCJ9fQ.3UKV9LTM8IFHJH_Z3z3XkrXgjdF_M7NqIi8VI5nK160").
final().
then(function (res) {
    console.log("----------->", res);
    return res;
});