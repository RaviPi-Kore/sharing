var sdk = require("./lib/sdk");
var Promise = sdk.Promise;
var request = require("request");
var config = require("./config");
const feedback = require('./feedback')
var pub = require("./lib/RedisClient.js").createClient(config.redis);
pub.config("SET", "notify-keyspace-events", "KExA");
var _ = require('lodash');
var botId = config.credentials.botId;
var botName = config.credentials.botName;

async function shutdown(e) {
    let err = e;
    console.log('Shutting down application');
    try {
        console.log('Closing database module');
        //      await database.close();
    } catch (e) {
        console.error(e);
        err = err || e;
    }
    console.log('Exiting process');
    if (err) {
        process.exit(1); // Non-zero failure code
    } else {
        process.exit(0);
    }
}
async function startup() {
    console.log('Starting application');
    try {
        console.log('Initializing database module');
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}
startup();
process.on('SIGTERM', () => {
    console.log('Received SIGTERM');
    shutdown();
});
process.on('SIGINT', () => {
    console.log('Received SIGINT');
    shutdown();
});
process.on('uncaughtException', err => {
    console.log('Uncaught exception');
    console.error(err);
    shutdown(err);
});

module.exports = {
    botId: botId,
    botName: botName,
    on_user_message: function (requestId, data, callback) {
        let uuid = data.channel.type + "/" + data.channel.from;
        pub.set(uuid + ":data", JSON.stringify(data));
        if (pub.get(uuid)) {
            pub.del(uuid);
        }
        sdk.sendBotMessage(data, callback);
    },
    on_bot_message: function (requestId, data, callback) {
        sdk.sendUserMessage(data, callback);
    },
    on_agent_transfer: function (requestId, data, callback) {
        console.log("Agent chat initaited")
        onAgentTransfer(requestId, data, callback);
    },
    lp_notification_event: function (notification) {
        lpNotification(notification);
    },
    get_history: function (userId) {
        gethistory(userId);
    },
    on_event: function (requestId, data, callback) {
        if (data.channel.type === 'rtm') {
            if (data.event.eventType === 'endFAQ') {
                console.log("End of dialog reached!!!!");
                let uuid = data.channel.type + "/" + data.channel.from;
                feedback(uuid, data, null);
                if (data.context.session.BotUserSession.rephraseCount) {
                    data.context.session.BotUserSession.rephraseCount = undefined;
                }
            }
            console.log("Displaying repharse count: ", data.context.session.BotUserSession.rephraseCount)
            if (data.event.eventType === 'endDialog' && !data.context.intent.includes("User Feedback") && !data.context.intent.includes("Welcome") && !data.context.intent.includes("Help") && !data.context.intent.includes("NoIntent")) {
                console.log("End of dialog reached!!!!");
                let uuid = data.channel.type + "/" + data.channel.from;
                feedback(uuid, data, null);
            }
            console.log("on_event --> Event : ", data.event, data.context.intent);
            return callback(null, data);
        }
    }
};