const request = require('request');
var Promise = require("bluebird");

function addCerts(config) {
    var opts = {};
    if (config.certFile)
        opts.cert = config.certFile;

    if (config.keyFile)
        opts.key = config.keyFile;

    if (config.caFile)
        opts.ca = config.caFile;

    if (config.passphrase)
        opts.passphrase = config.passphrase;

    if (config.securityOptions)
        opts.securityOptions = opts.securityOptions;

    return opts;
}

function makeRequest(url, method, body, opts) {
    var headers;
    var reqOptions = {
        url: url,
        method: method
    };

    opts = opts || {};
    headers = opts.headers || {};
    reqOptions.headers = headers;
    if (opts.ssgEnabled) {
        reqOptions.headers[options.ssgHeader] = options.host;
        var certs = addCerts(options);
        reqOptions = Object.assign(opts, certs);
    }

    if (body) {
        reqOptions.body = body;
    }
    reqOptions.json = true;

    console.log(JSON.stringify(reqOptions))
    return new Promise(function (resolve, reject) {
        request(reqOptions, function (err, res) {
            if (err) {
                return reject(err);
            }
            return resolve(res.body);
        });
    });
}

module.exports = {
    post: function (url, opts, body, callback) {
        return makeRequest(url, 'post', body, opts)
            .nodeify(callback);
    },
    get: function (url, callback) {
        return makeRequest(url, 'get')
            .nodeify(callback);
    },
    getWithOptions: function (url, opts, callback) {
        return makeRequest(url, 'get', undefined, opts)
            .nodeify(callback);
    }

};
