
function SetUserProfile(firstname, lastname, gender) {
  this.firstname = firstname;
  this.lastname = lastname;
  this.gender= gender;
}
module.exports = SetUserProfile;
