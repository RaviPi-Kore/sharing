function ConsumerRequestConversation(ttrDefName, channelType, brandId, skillId) {
    //this.ttrDefName = ttrDefName || "CUSTOM";
    //this.campaignInfo = campaignInfo || undefined;
    //this.channelType = channelType || "MESSAGING";
    this.brandId = brandId;
    //this.skillId = skillId || -1;
}
module.exports = ConsumerRequestConversation;
