function Event(type, contentType, message) {
  this.type = type;
  this.contentType = contentType;
  this.message = message;
}
module.exports = Event;
