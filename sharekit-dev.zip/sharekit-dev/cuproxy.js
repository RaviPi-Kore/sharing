var request = require('request-promise');
var config = require("./config");
var schedular = require('node-schedule');
const NodeCache = require("node-cache");
const cache = new NodeCache();


function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}


schedular.scheduleJob('*/45 * * * *', function () {
    callOAuthApi();
});



function callOAuthApi() {
    console.log('CallIng the OAuthToken');
    var data = {
        "grant_type": config.Oauth.grantType,
        "scope": config.Oauth.scope
    }
    var options = {
        method: 'POST',
        form: data,
        uri: config.Oauth.accessTokenUri,
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ' + new Buffer(config.Oauth.clientId + ':' + config.Oauth.clientSecret).toString('base64')
        }
    };
    console.log(" options:" + JSON.stringify(options));
    return request(options).then(function (res) {
        console.log(res);
        cache.set("token", res);
        console.log("Access Token from cache xxxxxxxxxx  " + cache.get("token"));
        return JSON.parse(res).access_token; // you can read response here
    }).catch(function (err) {
        return Promise.reject(err);
    });
}

function getJWTToken() {
    if (cache.get("token")) {
        return JSON.parse(cache.get("token")).access_token;
    } else {
        return callOAuthApi();
    }
}


function cuProxyApi(req, res) {
    try {
        console.log(JSON.stringify(req.body));
        var data = {
            "sourceApplicationId": config.connect.sourceApplicationId,
            "preferredLanguageCode": config.connect.preferredLanguageCode,
            "lineOfBusinessCode":config.connect.lineOfBusinessCode,
            "eligibilityOverrideFlag":"false",
            "campaignName":config.connect.campaignName,
            "smsMessageData":req.body.text,
            "smsMessageType":"",
            "phone": {
                "phoneNumber": req.body.to,
            },
            "portfolio": "SEARS",
            "_accountInfo": {
                "accountNumber": "string"
            }
        }
        var options = {
            method: 'POST',
            url: config.connect.api,
            body: data,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'uuid': uuid(),
                'Authorization': "bearer " +getJWTToken(),
                'countryCode': config.connect.countryCode,
                'businessCode': config.connect.businessCode,
                'channelId': config.connect.channelId,
                'Accept': 'application/json',
                'client_id': config.Oauth.clientId
            }
        };
        console.log("options are ", options);
        request(options, function (error, response, body) {
            if (!error) {
                console.log('CU response [' + response.statusCode + '] body:  ' + body);
                // Need to make the call to CU, to get the status
                res.json({
                    "code": "ok"
                });
            } else {
                console.log('Error happened in cuproxy ' + error);
            }
        });
    } catch (err) {
        console.log("error in cuproxy", err);
    }
}

module.exports = {
    cuProxyApi,
    callOAuthApi
}