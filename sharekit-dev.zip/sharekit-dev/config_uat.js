var dit = {
    "server": {
        "port": 8003
    },
    "app": {
        "apiPrefix": "/botkit"
    },
    "credentials": {
        "apikey": "fTWr34+QqoqaT97wa4pAq9/4crX//ipyJnVRcLxkJS0=",
        "appId": "cs-b801d4e9-b510-54d6-9cc4-142fd8e7cb1d",
        "botId": "st-fc77c68b-a12c-5024-aae0-7aa1680690fa",
        "botName": "CITI CRS BOT"
    },
    "connect": {
        "api": ""
    },
    "redis": {
        "options": {
            "host": "localhost",
            "port": 6379
        },
        "available": false
    },
    "oracle": {
        "username": "rp91136",
        "password": "Ravi@123",
        "host": "vm-c231-8dd3",
        poolMin: 10,
        poolMax: 10,
        poolIncrement: 0
    },
    "liveperson": {
        "accountId": "70208405",
        "clientSecret": "mpfj66i4i8p3ea6vkof1o1n020",
        "clientId": "735a3e9b-af2c-4595-b7df-6dd445672970"
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": ["en", "de"]
};

module.exports = dit;