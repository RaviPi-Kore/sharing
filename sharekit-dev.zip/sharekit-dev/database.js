var oracledb = require('oracledb');
var config = require('./config.js');


async function initialize() {
    await oracledb.createPool(config.oracle);
    console.log('Connection was successful!');
}

module.exports.initialize = initialize;

async function close() {
    await oracledb.getPool().close();
}

module.exports.close = close;
