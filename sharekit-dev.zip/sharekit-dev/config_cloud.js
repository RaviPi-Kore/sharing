var cloud = {
    "server": {
        "port": 8003
    },
    "app": {
        "apiPrefix": "/lpconnector"
    },
    "credentials": {
        "apikey": "g0zOy7/cjNqhU/Ubd9XjwJw/C1WG1aEjpIlOjngYjQQ=",
        "appId": "cs-ade0cb80-2336-532a-a884-38629aa94686",
        "botId": "st-41e89697-9594-54d8-b625-72404c51e7d2",
        "botName": "Citi CRS"
    },
    "lpdemo": {
        "apikey": "g0zOy7/cjNqhU/Ubd9XjwJw/C1WG1aEjpIlOjngYjQQ=",
        "appId": "cs-ade0cb80-2336-532a-a884-38629aa94686",
        "botId": "st-be6ea1e0-6629-5be3-b586-6a26356ef03f",
        "botName": "LP DEMO"
    },
    "connect": {
        "api": "https://sit.api.citigroup.net/gcgapi/dev3/api/private/v1/bank/customers/phone/outbound/alerts",
        "sourceApplicationId": "KOREAI",
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "DESKTOP",
        "client_id":"d2cee650-dd72-4e44-a618-8dbc2e0d0efc",
        "lineOfBusinessCode":"CRS",
        "campaignName":"PYMT_REMINDER",
        "preferredLanguageCode":"EN"
    },
    "kore": {
        "api": "https://bots.kore.ai/chatbot/hooks/st-41e89697-9594-54d8-b625-72404c51e7d2"
    },
    "oracle": {
        "username": "",
        "password": "",
        "host": ""
    },
    "liveperson": {
        "accountId": "70208405",
        "clientSecret": "mpfj66i4i8p3ea6vkof1o1n020",
        "clientId": "735a3e9b-af2c-4595-b7df-6dd445672970",
        "host": "http://api.liveperson.net"
    },

    "Oauth": {
        "clientId": "d2cee650-dd72-4e44-a618-8dbc2e0d0efc",
        "clientSecret": "B2oL5pS5yW3oY6tS0aN6wE3yV4rL7nI0yY4uO1bU3uO4oU3sK7",
        "scope": "/api",
        "grantType": "client_credentials",
        "accessTokenUri": "https://sit.api.citigroup.net/gcgapi/uat3/api/oauth/token"
    },

    "accountApi": {
        "countryCode": "US",
        "businessCode": "CRS",
        "channelId": "CRSDESKTOP",
        "endPoint": "http://demo3424779.mockable.io/retailCards/phone/userValidation"
    },
    "redis": {
        "options": {
            "host": "localhost",
            "port": 6379
        },
        "available": true
    },
    "examples": {
        "mockServicesHost": "http://localhost:8004"
    },
    "liveagentlicense": "8947569",
    "supportsMessageAck": true,
    "languages": ["en", "de"]
};

module.exports = cloud;