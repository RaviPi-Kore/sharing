const DIT = require('./config_dit');
const CLOUD= require('./config_cloud');

const UAT= require('./config_uat');

//const env = process.env.NODE_ENV;

const env = "CLOUD";
const config = {
    DIT,
    CLOUD,
    UAT
};

module.exports = config[env]; 
